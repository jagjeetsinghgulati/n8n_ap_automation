NEXT BATCH: FIVE ADDITIONAL FICTIONAL INVOICES

All five PDFs use A4 portrait pages and selectable text.
They have new vendor/invoice identities for a second training batch.
Copy the five PDF files into invoice_demo_v2\input, then execute the V2 workflow.
Do not copy this README into input. The workflow reads the top level of input only.

Expected gross amounts (INR):
21 Papertrail Archive Services     PAS/26-27/1041     12,154.00
22 Sundial Pneumatics Pvt Ltd      SP/26-27/1042      43,447.60
23 Aavrit Business Connectivity    ABC/26-27/1043     24,780.00
24 Neelvan Environmental Testing   NET/26-27/1044     31,801.00
25 Rookline Media Works            RMW/26-27/1045     43,778.00
TOTAL                                              155,960.60

Text readability, distinct invoice identities and arithmetic were checked during
preparation. Actual local-model extraction must be reviewed during your run.
All business, tax and payment details are fictional and for training only.
