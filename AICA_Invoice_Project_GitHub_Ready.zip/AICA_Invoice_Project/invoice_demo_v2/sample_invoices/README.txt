20 VARIED VENDOR INVOICES - TRAINING PACK

Copy ONLY the 20 PDF files to your V2 input folder when ready to test.
Keep this README, expected_results.csv and expected_invoice_data.json outside input.
The PDFs are selectable text; this pack does not test OCR for scanned images.
All businesses, GST-like identifiers, addresses, contacts, bank references and transactions
are invented. Each PDF carries a discreet fictional-transaction footer.
HSN/SAC and tax examples are for extraction demonstrations, not legal/tax guidance.

Every invoice has a different design and a different fictional vendor. All invoices
use INR. No duplicate is deliberately included in the initial pack.
Upload a copy of an already processed PDF in a later batch to demonstrate duplicate recognition.

DELIBERATE REVIEWS
15: Printed grand total is INR 700.00 too high; all line values and tax components remain as printed.
18: INR 15,000 refundable security deposit is included as other charges, requiring accounting review.
19: Due date is explicitly not stated.
07 and 20: Computer equipment/furniture should receive capitalisation/ledger review.
Other accounting review flags may depend on configured materiality and ledger rules.

EXPECTED DATA
expected_results.csv gives totals, layout, and deliberate exceptions per PDF.
expected_invoice_data.json gives the source-grounded extraction answer key.
These references are for the trainer; the language model should read the PDFs, not this answer key.

The invoice total check should find exactly one arithmetic mismatch, PDF 15.
This pack is not an assertion that an invoice passing arithmetic checks is approved for posting.

Category values in the JSON answer key use the workflow-supported category list.
These are suggested reviewer judgments, not values printed on the invoice. Equipment
hire with a deposit is classified Other because it contains hire and deposit components;
the reviewer should split the accounting treatment. Metal inputs, safety supplies,
industrial oils, electrical components and furniture also use Other pending ledger review.
