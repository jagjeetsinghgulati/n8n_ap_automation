@echo off
setlocal
powershell.exe -NoLogo -NoProfile -File "%~dp0scripts\Manage.ps1" -Action stop
if errorlevel 1 echo Operation did not complete. Read the error above.
pause
