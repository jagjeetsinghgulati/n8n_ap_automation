"""Deterministic invoice and proposed-entry checks; no tax eligibility decisions.

The model supplies document facts and category suggestions. This module never
approves an invoice: the application must approve an exact revision separately.
All arithmetic uses Decimal and monetary comparisons use paise precision.
"""
from __future__ import annotations

import re
from datetime import date
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

CENT = Decimal("0.01")
MAX_NUMBER = Decimal("1000000000000000")
AMOUNTS = ("taxable_value", "cgst", "sgst", "igst", "other_charges", "round_off", "invoice_total")
TEXT_FIELDS = ("invoice_number", "supplier_name", "supplier_gstin", "buyer_name",
               "invoice_date", "due_date", "currency", "document_type", "description",
               "notes", "category", "category_reason", "source_file", "raw_text")
CATEGORIES = ("Office supplies", "Software", "Professional services", "Rent",
              "IT equipment", "Freight", "Packaging", "Repairs", "Cleaning",
              "Deposit or advance", "Training", "Other")
CATEGORY_LEDGERS = {
    "Office supplies": "Office Supplies Expense", "Software": "Software Expense",
    "Professional services": "Professional Fees", "Rent": "Rent Expense",
    "IT equipment": "Computer Equipment - review", "Freight": "Freight Expense",
    "Packaging": "Packaging Expense", "Repairs": "Repairs and Maintenance",
    "Cleaning": "Cleaning Expense", "Deposit or advance": "Deposits and Advances - review",
    "Training": "Training Expense", "Other": "Other Expense - review",
}
SUGGESTED_LEDGERS = list(CATEGORY_LEDGERS.values()) + [
    "CGST - treatment to review", "SGST - treatment to review", "IGST - treatment to review"]
HARD_SOURCE_FLAGS = {"PDF_READ_ERROR", "NO_READABLE_TEXT", "LLM_EXTRACTION_ERROR",
                     "EXTRACTION_ERROR", "PROCESSING_ERROR", "BATCH_INTERRUPTED"}
SOURCE_MESSAGES = {
    "PDF_READ_ERROR": "PDF extraction failed. Correct the data from the original document before approval.",
    "NO_READABLE_TEXT": "No usable PDF text. Supply a text PDF or manually verify and correct its data.",
    "LLM_EXTRACTION_ERROR": "The local model did not return usable invoice data. Reprocess or correct it.",
    "TEXT_TRUNCATED": "Only part of the document was extracted. Verify all pages and invoice lines.",
    "SOURCE_MISMATCH": "An extracted fact was not corroborated in the document text. Compare it with the PDF.",
}
DERIVED_FLAGS = {"MISSING_INVOICE_NUMBER", "MISSING_SUPPLIER", "MISSING_GSTIN", "GSTIN_FORMAT",
    "MISSING_DATE", "MISSING_DUE_DATE", "DATE_ORDER", "FUTURE_INVOICE", "CURRENCY_REVIEW",
    "DOCUMENT_REVIEW", "MISSING_AMOUNTS", "TOTAL_MISMATCH", "LINE_TOTAL_MISMATCH",
    "LINE_CALCULATION", "MISSING_LINES", "CAPEX_REVIEW", "DEPOSIT_REVIEW", "PROFESSIONAL_REVIEW",
    "HIGH_VALUE", "NEGATIVE_AMOUNT", "DUPLICATE_CONFLICT", "POTENTIAL_DUPLICATE"}


def _decimal(value) -> Decimal:
    """Parse only actual numbers or decimal strings; do not coerce bool or null."""
    if isinstance(value, bool) or value is None or not isinstance(value, (str, int, float, Decimal)):
        raise ValueError("Expected a finite number, not a boolean, object or null.")
    if isinstance(value, str):
        value = value.strip()
        if not value or len(value) > 80 or not re.fullmatch(r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?", value):
            raise ValueError("Use plain numeric values without currency symbols or commas.")
    try:
        number = Decimal(str(value))
    except (InvalidOperation, ValueError) as exc:
        raise ValueError("Invalid numeric value.") from exc
    if not number.is_finite() or abs(number) >= MAX_NUMBER:
        raise ValueError("Number must be finite and below 1,000,000,000,000,000 in absolute value.")
    return number


def money(value) -> Decimal:
    """Return a finite monetary value rounded half up to paise; blanks raise."""
    try:
        return _decimal(value).quantize(CENT, rounding=ROUND_HALF_UP)
    except InvalidOperation as exc:
        raise ValueError("Invalid monetary precision.") from exc


def _blank(value) -> bool:
    return value is None or (isinstance(value, str) and not value.strip())


def _optional_number(value, field, monetary=True):
    if _blank(value):
        return None
    try:
        num = money(value) if monetary else _decimal(value)
    except ValueError as exc:
        raise ValueError(f"{field}: {exc}") from exc
    # JSON uses numbers; all subsequent arithmetic reparses decimal strings.
    return float(num)


def _text(value, field, limit=4000):
    if value is None:
        return None
    if not isinstance(value, str):
        raise ValueError(f"{field} must be text or blank.")
    value = value.strip()
    if len(value) > limit:
        raise ValueError(f"{field} exceeds {limit} characters.")
    return value or None


def sanitize_data(data) -> dict:
    """Canonical V1 schema. Preserve source text/flags; never trust status fields.

    Missing monetary values remain None, including tax amounts. A reviewer must
    explicitly establish zero where appropriate. Quantity and unit-price precision
    are preserved; calculated line monetary values round only at comparison time.
    """
    if not isinstance(data, dict):
        raise ValueError("Invoice data must be an object.")
    result = {key: _text(data.get(key), key, 250000 if key == "raw_text" else 4000)
              for key in TEXT_FIELDS}
    for key in ("currency", "document_type", "supplier_gstin"):
        if result[key]:
            result[key] = result[key].upper()
    if result["category"] not in CATEGORIES:
        result["category"] = "Other"
    for key in AMOUNTS:
        result[key] = _optional_number(data.get(key), key)
    flags = data.get("flags", [])
    if not isinstance(flags, list) or len(flags) > 200 or any(not isinstance(f, str) for f in flags):
        raise ValueError("flags must be a list of text codes.")
    if any(len(flag) > 200 for flag in flags):
        raise ValueError("Flag code is too long.")
    result["flags"] = list(dict.fromkeys(f.strip() for f in flags if f.strip()))
    lines = data.get("line_items", [])
    if lines is None:
        lines = []
    if not isinstance(lines, list) or len(lines) > 1000:
        raise ValueError("line_items must be a list of at most 1,000 lines.")
    result["line_items"] = []
    for index, line in enumerate(lines, 1):
        if not isinstance(line, dict):
            raise ValueError(f"Line {index} must be an object.")
        result["line_items"].append({
            "description": _text(line.get("description"), f"Line {index} description"),
            "quantity": _optional_number(line.get("quantity"), f"Line {index} quantity", False),
            "unit_price": _optional_number(line.get("unit_price"), f"Line {index} unit_price", False),
            "taxable_amount": _optional_number(line.get("taxable_amount"), f"Line {index} taxable_amount"),
        })
    return result


def _date(value):
    if not isinstance(value, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
        return None
    try:
        return date.fromisoformat(value)
    except ValueError:
        return None


def _norm(value):
    return re.sub(r"[^A-Z0-9]", "", str(value or "").upper())


def invoice_identity(data, company) -> tuple:
    """Company, supplier GSTIN/name, Indian April-March FY, invoice reference.

    This conservative normalization can flag punctuation variants for review.
    It is never evidence that two PDFs may be discarded automatically.
    """
    inv_date = _date(data.get("invoice_date"))
    year = inv_date.year - (inv_date.month < 4) if inv_date else None
    fiscal_year = f"{year}-{str(year + 1)[-2:]}" if year else ""
    supplier = _norm(data.get("supplier_gstin") or data.get("supplier_name"))
    return (_norm(company), supplier, fiscal_year, _norm(data.get("invoice_number")))


def suggest_voucher(data, company) -> dict:
    return {"company": str(company or "").strip(), "voucher_type": "Purchase",
            "voucher_date": data.get("invoice_date") or ""}


def suggest_entries(data) -> list:
    """Reviewable gross purchase proposal, not a conclusion about deductible GST.

    Non-INR, missing/negative components or credit documents produce no proposal.
    A negative round-off reduces the base debit rather than creating another credit.
    Reviewer confirms exact Tally ledger names and accounting/tax treatment.
    """
    try:
        vals = {key: money(data.get(key)) for key in AMOUNTS}
    except ValueError:
        return []
    if str(data.get("currency") or "").upper() != "INR" or data.get("document_type") != "INVOICE":
        return []
    if any(vals[k] < 0 for k in AMOUNTS if k != "round_off") or vals["invoice_total"] <= 0:
        return []
    base = vals["taxable_value"] + vals["other_charges"] + vals["round_off"]
    if base < 0:
        return []
    narr = f"Invoice {data.get('invoice_number') or '(missing reference)'} dated {data.get('invoice_date') or '(missing date)'}. Ledger/tax treatment to be reviewed."
    entries = []
    def add(ledger, debit=Decimal(0), credit=Decimal(0)):
        if debit or credit:
            entries.append({"ledger": ledger, "debit": float(debit), "credit": float(credit),
                            "cost_centre": "", "narration": narr})
    add(CATEGORY_LEDGERS.get(data.get("category"), CATEGORY_LEDGERS["Other"]), base)
    for key in ("cgst", "sgst", "igst"):
        add(f"{key.upper()} - treatment to review", vals[key])
    add(str(data.get("supplier_name") or "").strip(), credit=vals["invoice_total"])
    return entries


def checks(data, entries, voucher, settings, duplicate_candidates=None) -> list:
    """Return blocking validation findings and explicitly waivable review findings.

    Missing lines may be accepted by a named reviewer with an explanation. Missing
    invoice amounts, arithmetic failures, duplicates and incomplete/unbalanced
    entries cannot be waived. A past due date does not establish unpaid liability.
    """
    out = []
    seen = set()
    def add(code, severity, message):
        if code not in seen:
            out.append({"code": code, "severity": severity, "message": message})
            seen.add(code)
    if not isinstance(data, dict):
        return [{"code": "INVALID_DATA", "severity": "block", "message": "Invoice data must be an object."}]
    settings = settings if isinstance(settings, dict) else {}
    voucher = voucher if isinstance(voucher, dict) else {}
    for flag in data.get("flags", []) or []:
        if not isinstance(flag, str) or flag in DERIVED_FLAGS:
            continue  # Derived findings are recomputed for the current revision.
        hard = flag in HARD_SOURCE_FLAGS or flag.startswith(("LLM_", "INVALID_NUMBER_"))
        add(flag, "block" if hard else "review", SOURCE_MESSAGES.get(flag, f"Source processing finding: {flag}. Verify the original invoice."))

    if not str(data.get("invoice_number") or "").strip():
        add("MISSING_INVOICE_NUMBER", "block", "Invoice number is required.")
    if not str(data.get("supplier_name") or "").strip():
        add("MISSING_SUPPLIER", "block", "Supplier name is required.")
    inv_date = _date(data.get("invoice_date"))
    due_date = _date(data.get("due_date"))
    as_of = _date(settings.get("asOfDate")) or date.today()
    if not inv_date:
        add("MISSING_DATE", "block", "A valid invoice date in YYYY-MM-DD format is required.")
    if not due_date:
        add("MISSING_DUE_DATE", "review", "Due date is missing or invalid. Obtain the terms; payment status remains unknown.")
    if inv_date and due_date and due_date < inv_date:
        add("DATE_ORDER", "review", "Due date is before invoice date. Verify both dates.")
    if inv_date and inv_date > as_of:
        add("FUTURE_INVOICE", "review", "Invoice date is after the reporting date. Confirm the document and period.")
    if str(data.get("currency") or "").upper() != "INR":
        add("CURRENCY_REVIEW", "block", "This version supports INR invoices only; confirm currency from the document.")
    if str(data.get("document_type") or "").upper() != "INVOICE":
        add("DOCUMENT_REVIEW", "block", "Only ordinary invoices are supported. Credit notes and other document types need a separate process.")
    gstin = str(data.get("supplier_gstin") or "").strip().upper()
    if not gstin:
        add("MISSING_GSTIN", "review", "Supplier GSTIN is missing. Verify supplier registration and document requirements.")
    elif not re.fullmatch(r"\d{2}[A-Z]{5}\d{4}[A-Z][A-Z0-9]Z[A-Z0-9]", gstin):
        add("GSTIN_FORMAT", "review", "Supplier GSTIN format needs review. This check does not validate a registration or checksum.")
    values = {}
    missing = []
    for key in AMOUNTS:
        try:
            values[key] = money(data.get(key))
        except ValueError:
            missing.append(key)
    if missing:
        add("MISSING_AMOUNTS", "block", "Confirm every amount, including explicit zero tax/charge values where appropriate: " + ", ".join(missing) + ".")
    if any(value < 0 for key, value in values.items() if key != "round_off"):
        add("NEGATIVE_AMOUNT", "block", "Negative invoice components are unsupported in this ordinary-invoice process.")
    if values.get("invoice_total", Decimal(1)) <= 0:
        add("NONPOSITIVE_TOTAL", "block", "Invoice total must be greater than zero.")
    # Configured source arithmetic tolerance does not relax journal balancing.
    try:
        source_tolerance = money(settings.get("toleranceINR", 0.01))
        if source_tolerance < 0:
            source_tolerance = CENT
    except ValueError:
        source_tolerance = CENT
    tolerance = CENT
    if len(values) == len(AMOUNTS):
        computed = sum((values[k] for k in AMOUNTS if k != "invoice_total"), Decimal(0))
        diff = values["invoice_total"] - computed
        if abs(diff) > source_tolerance:
            add("TOTAL_MISMATCH", "block", f"Invoice total differs from taxable value plus taxes, charges and round-off by INR {diff:.2f}.")

    lines = data.get("line_items") or []
    if not isinstance(lines, list):
        add("MISSING_LINES", "review", "Line detail is invalid. Enter or confirm the supporting detail before approving.")
        lines = []
    if not lines:
        add("MISSING_LINES", "review", "No invoice lines were extracted. Verify the PDF and document why header-level accounting is sufficient.")
    line_amounts = []
    for index, line in enumerate(lines, 1):
        if not isinstance(line, dict):
            add("MISSING_LINES", "review", "Some line detail is missing or invalid. Verify the PDF.")
            continue
        nums = {}
        for key in ("quantity", "unit_price", "taxable_amount"):
            try:
                nums[key] = _decimal(line.get(key))
            except ValueError:
                add("MISSING_LINES", "review", "Some descriptions, quantities, rates or line amounts are missing. Verify the PDF.")
        if not line.get("description"):
            add("MISSING_LINES", "review", "Some line descriptions are missing. Verify the PDF.")
        if any(val < 0 for val in nums.values()):
            add("NEGATIVE_LINE_AMOUNT", "block", "Negative quantities, rates or line amounts require a separate adjustment process.")
        if "taxable_amount" in nums:
            line_amounts.append(money(nums["taxable_amount"]))
        if len(nums) == 3:
            try:
                calculated_line = money(nums["quantity"] * nums["unit_price"])
                if abs(calculated_line - money(nums["taxable_amount"])) > source_tolerance:
                    add("LINE_CALCULATION", "review", "Quantity times rate differs from a line amount. Check printed discounts or other line adjustments.")
            except ValueError:
                add("LINE_NUMBER_RANGE", "block", "A quantity multiplied by its rate is outside the supported numeric range. Correct the line data.")
    if lines and len(line_amounts) == len(lines) and "taxable_value" in values:
        if abs(sum(line_amounts, Decimal(0)) - values["taxable_value"]) > source_tolerance:
            add("LINE_TOTAL_MISMATCH", "block", "Extracted line taxable amounts do not sum to the invoice taxable value. Correct or explain the actual lines in the data.")

    text = " ".join(str(data.get(k) or "") for k in ("raw_text", "description", "category", "notes"))
    if data.get("category") == "IT equipment" or re.search(r"\b(laptop|computer|equipment|capital asset)\b", text, re.I):
        add("CAPEX_REVIEW", "review", "Equipment purchase: confirm expense versus capital asset treatment and the ledger.")
    if data.get("category") == "Deposit or advance" or re.search(r"\b(refundable|security deposit|advance payment)\b", text, re.I):
        add("DEPOSIT_REVIEW", "review", "Deposit or advance: confirm balance-sheet treatment and supporting terms.")
    if data.get("category") == "Professional services" or re.search(r"\b(consulting|professional fee|legal fee)\b", text, re.I):
        add("PROFESSIONAL_REVIEW", "review", "Professional service: review the contract, applicable deductions and accounting treatment.")
    try:
        threshold = money(settings.get("highValueThreshold", 100000))
    except ValueError:
        threshold = Decimal("100000")
    if "invoice_total" in values and values["invoice_total"] > threshold:
        add("HIGH_VALUE", "review", f"Invoice exceeds the configured review threshold of INR {threshold:.2f}; this is not a statutory limit.")
    if duplicate_candidates:
        add("POTENTIAL_DUPLICATE", "block", "Another active or recorded invoice has the same supplier, reference and financial year. Resolve it as a duplicate or replacement before approval.")

    if not str(voucher.get("company") or "").strip():
        add("VOUCHER_COMPANY", "block", "Tally company is required for the proposed entry.")
    if settings.get("companyName") and _norm(voucher.get("company")) != _norm(settings["companyName"]):
        add("COMPANY_MISMATCH", "block", "Proposed company must match this invoice workspace's company.")
    if not str(voucher.get("voucher_type") or "").strip():
        add("VOUCHER_TYPE", "block", "Voucher type is required.")
    if not _date(voucher.get("voucher_date")):
        add("VOUCHER_DATE", "block", "A valid voucher date in YYYY-MM-DD format is required.")
    if not isinstance(entries, list) or not entries:
        add("MISSING_ENTRIES", "block", "Prepare and review the debit/credit lines before approval.")
        return out
    debit_total = credit_total = Decimal(0)
    credit_amounts = []
    valid_entries = True
    for index, entry in enumerate(entries, 1):
        if not isinstance(entry, dict):
            add("INVALID_ENTRY", "block", "Each accounting entry must be an object.")
            valid_entries = False
            continue
        if not isinstance(entry.get("ledger"), str) or not entry["ledger"].strip():
            add("MISSING_LEDGER", "block", "Every accounting line needs a reviewed Tally ledger name.")
        try:
            debit = money(entry.get("debit"))
            credit = money(entry.get("credit"))
        except ValueError:
            add("INVALID_ENTRY_AMOUNT", "block", "Every accounting line requires numeric debit and credit values; enter zero on the unused side.")
            valid_entries = False
            continue
        if debit < 0 or credit < 0 or (debit > 0 and credit > 0) or (debit == 0 and credit == 0):
            add("INVALID_ENTRY_SIDE", "block", "Each accounting line must have one positive debit or credit and zero on the other side.")
        debit_total += debit
        credit_total += credit
        if credit > 0:
            credit_amounts.append(credit)
    if valid_entries:
        if abs(debit_total - credit_total) > tolerance:
            add("UNBALANCED_ENTRY", "block", f"Debits and credits differ by INR {debit_total-credit_total:.2f}.")
        if "invoice_total" in values and (abs(debit_total-values["invoice_total"]) > tolerance or abs(credit_total-values["invoice_total"]) > tolerance):
            add("ENTRY_TOTAL_MISMATCH", "block", "Total debits and credits must each equal the invoice gross amount.")
        if "invoice_total" in values and (len(credit_amounts) != 1 or abs(credit_amounts[0]-values["invoice_total"]) > tolerance):
            add("SUPPLIER_PAYABLE_MISMATCH", "block", "Use one supplier credit equal to the invoice gross amount. Split payables/deductions require a separately reviewed process.")
    return out
