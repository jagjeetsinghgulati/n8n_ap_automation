#!/usr/bin/env python3
"""Local invoice approval V2. Python standard library; one local reviewer service."""
import argparse, base64, contextlib, datetime as dt, hashlib, hmac, http.cookies, io, json, logging, mimetypes, os, re, secrets, shutil, sqlite3, sys, tempfile, threading, time, urllib.parse, zipfile
from decimal import Decimal
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from domain import sanitize_data, checks, suggest_entries, suggest_voucher, invoice_identity, SUGGESTED_LEDGERS
from reports import write_xlsx

VERSION='2.0.0'
ROOT=Path(os.environ.get('ROOT_DIR',str(Path(__file__).resolve().parent.parent))).resolve()
DATA=Path(os.environ.get('DATA_DIR',str(ROOT/'local_database'))).resolve()
N8N_PREFIX=os.environ.get('N8N_FILES_PREFIX','/files/invoice_demo_v2').rstrip('/')
PORT=int(os.environ.get('PORT','8787'))
TOKEN=os.environ.get('INVOICE_API_TOKEN','')
USER=os.environ.get('INVOICE_USER','reviewer')
PASSWORD=os.environ.get('INVOICE_PASSWORD','')
LOCK=threading.RLock(); SESSIONS={}; LOGIN_ATTEMPTS={}; DB=None
STATUSES=('processing','processing_problem','awaiting_approval','on_hold','returned_for_correction','approved_awaiting_entry','manually_recorded','rejected_closed')
OPEN_STATUSES=STATUSES[:-2]
DEFAULT_SETTINGS={'companyName':'Northstar Precision Components Pvt Ltd','highValueThreshold':100000,'toleranceINR':1,'model':'qwen2.5:7b','asOfDate':dt.datetime.now(dt.timezone(dt.timedelta(hours=5,minutes=30))).date().isoformat()}
class Problem(Exception):
    def __init__(self,message,status=400): self.message=message; self.status=status

def now(): return dt.datetime.now(dt.timezone.utc).isoformat(timespec='seconds')
def jd(v): return json.dumps(v,ensure_ascii=False,allow_nan=False,separators=(',',':'))
def jl(v,default=None): return json.loads(v) if v else ({} if default is None else default)
def row(query,args=()):
    r=DB.execute(query,args).fetchone(); return dict(r) if r else None
def rows(query,args=()): return [dict(r) for r in DB.execute(query,args)]
def cleantext(v,n=1000): return str(v or '').strip()[:n]
def require_reason(d):
    s=cleantext(d.get('reason'),2000)
    if len(s)<3: raise Problem('Please enter a meaningful reason (at least three characters).')
    return s
def event(i,actor,action,reason='',version=None,batch=None):
    DB.execute('INSERT INTO events(invoice_id,actor,action,reason,version,batch_id,timestamp) VALUES(?,?,?,?,?,?,?)',(i,actor,action,reason,version,batch,now()))
def get_settings(): return jl(row('SELECT value FROM settings WHERE key=?',('settings',))['value'])
def get_invoice(i):
    r=row('SELECT * FROM invoices WHERE id=?',(i,))
    if not r: raise Problem('Invoice not found.',404)
    return r
def get_version(i,v=None):
    if v is None: v=get_invoice(i)['current_version']
    r=row('SELECT * FROM versions WHERE invoice_id=? AND version=?',(i,int(v)))
    if not r: raise Problem('Invoice version not found.',404)
    r['data']=jl(r.pop('data_json'));r['entries']=jl(r.pop('entries_json'),[]);r['voucher']=jl(r.pop('voucher_json'))
    return r
def version_history(i,v):
    result=get_version(i,v)
    payload=row('SELECT payload_json,received_at FROM extraction_payloads WHERE invoice_id=? AND version=?',(i,v))
    if payload:result['original_extraction']={'received_at':payload['received_at'],'payload':jl(payload['payload_json'])}
    return result
def check_version(i,d):
    inv=get_invoice(i)
    if d.get('version')!=inv['current_version']: raise Problem('This invoice changed. Refresh it and review the latest version.',409)
    return inv

def init_db():
    global DB
    for folder in ('input','archive','output','backups','output/outlook'): (ROOT/folder).mkdir(parents=True,exist_ok=True)
    DATA.mkdir(parents=True,exist_ok=True)
    DB=sqlite3.connect(DATA/'invoice_control_v2.db',check_same_thread=False,timeout=30)
    DB.row_factory=sqlite3.Row
    DB.execute('PRAGMA foreign_keys=ON');DB.execute('PRAGMA journal_mode=WAL');DB.execute('PRAGMA synchronous=FULL')
    DB.executescript('''
    CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS batches(id TEXT PRIMARY KEY,run_key TEXT UNIQUE NOT NULL,status TEXT NOT NULL,started_at TEXT NOT NULL,finished_at TEXT,received INTEGER DEFAULT 0,new_count INTEGER DEFAULT 0,duplicate_count INTEGER DEFAULT 0,error_count INTEGER DEFAULT 0,completed_count INTEGER DEFAULT 0,opening_json TEXT NOT NULL,config_json TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS invoices(id TEXT PRIMARY KEY,batch_id TEXT NOT NULL,source_file TEXT NOT NULL,current_version INTEGER NOT NULL,status TEXT NOT NULL,created_at TEXT NOT NULL,updated_at TEXT NOT NULL,export_id TEXT,approval_json TEXT,manual_json TEXT,FOREIGN KEY(batch_id) REFERENCES batches(id));
    CREATE TABLE IF NOT EXISTS documents(id TEXT PRIMARY KEY,invoice_id TEXT NOT NULL,filename TEXT NOT NULL,sha256 TEXT UNIQUE NOT NULL,archive_name TEXT NOT NULL,created_at TEXT NOT NULL,FOREIGN KEY(invoice_id) REFERENCES invoices(id));
    CREATE TABLE IF NOT EXISTS versions(invoice_id TEXT NOT NULL,version INTEGER NOT NULL,document_id TEXT,data_json TEXT NOT NULL,entries_json TEXT NOT NULL,voucher_json TEXT NOT NULL,source TEXT NOT NULL,created_at TEXT NOT NULL,extraction_received INTEGER DEFAULT 0,PRIMARY KEY(invoice_id,version),FOREIGN KEY(invoice_id) REFERENCES invoices(id),FOREIGN KEY(document_id) REFERENCES documents(id));
    CREATE TABLE IF NOT EXISTS extraction_payloads(invoice_id TEXT NOT NULL,version INTEGER NOT NULL,payload_json TEXT NOT NULL,received_at TEXT NOT NULL,PRIMARY KEY(invoice_id,version),FOREIGN KEY(invoice_id,version) REFERENCES versions(invoice_id,version));
    CREATE TABLE IF NOT EXISTS receipts(id INTEGER PRIMARY KEY AUTOINCREMENT,batch_id TEXT NOT NULL,invoice_id TEXT,version INTEGER,filename TEXT NOT NULL,outcome TEXT NOT NULL,error TEXT,FOREIGN KEY(batch_id) REFERENCES batches(id));
    CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice_id TEXT,actor TEXT NOT NULL,action TEXT NOT NULL,reason TEXT,version INTEGER,batch_id TEXT,timestamp TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS exports(id TEXT PRIMARY KEY,kind TEXT NOT NULL,filename TEXT NOT NULL,created_at TEXT NOT NULL,count INTEGER NOT NULL,status TEXT NOT NULL,snapshot_json TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS export_items(export_id TEXT NOT NULL,invoice_id TEXT NOT NULL,version INTEGER NOT NULL,PRIMARY KEY(export_id,invoice_id),FOREIGN KEY(export_id) REFERENCES exports(id),FOREIGN KEY(invoice_id) REFERENCES invoices(id));
    CREATE TABLE IF NOT EXISTS email_jobs(id TEXT PRIMARY KEY,export_id TEXT NOT NULL,status TEXT NOT NULL,message TEXT,created_at TEXT NOT NULL);
    CREATE INDEX IF NOT EXISTS events_invoice ON events(invoice_id,id);
    CREATE INDEX IF NOT EXISTS receipts_batch ON receipts(batch_id);
    ''')
    DB.execute('INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)',('settings',jd(DEFAULT_SETTINGS)))
    DB.commit()

def header(inv):
    v=get_version(inv['id']);d=v['data'];age=max(0,(dt.datetime.now(dt.timezone.utc)-dt.datetime.fromisoformat(inv['created_at'])).days)
    return {**{k:inv[k] for k in ('id','batch_id','current_version','status','updated_at','export_id')},'source_file':d.get('source_file') or inv['source_file'],'original_source_file':inv['source_file'],'supplier_name':d.get('supplier_name'),'invoice_number':d.get('invoice_number'),'invoice_date':d.get('invoice_date'),'invoice_total':d.get('invoice_total'),'age_days':age,'flags':[x['code'] for x in get_checks(inv,v)],'manual_reference':jl(inv.get('manual_json'))}

def duplicates(inv,v):
    data=v['data'];ident=invoice_identity(data,v['voucher'].get('company',''))
    if not data.get('invoice_number') or not data.get('supplier_name'):return []
    def norm(s): return re.sub('[^A-Z0-9]','',str(s or '').upper())
    matches=[]
    for other in rows("SELECT * FROM invoices WHERE id<>? AND status<>'rejected_closed'",(inv['id'],)):
        ov=get_version(other['id']);od=ov['data'];oi=invoice_identity(od,ov['voucher'].get('company',''))
        if ident[0]!=oi[0] or ident[2:]!=oi[2:]: continue
        gst=norm(data.get('supplier_gstin'));ogst=norm(od.get('supplier_gstin'))
        if (gst and ogst and gst==ogst) or norm(data.get('supplier_name'))==norm(od.get('supplier_name')):
            matches.append({'id':other['id'],'invoice_number':od.get('invoice_number'),'supplier_name':od.get('supplier_name'),'invoice_total':od.get('invoice_total'),'status':other['status']})
    return matches

def get_checks(inv,v):
    return checks(v['data'],v['entries'],v['voucher'],get_settings(),duplicates(inv,v))

def detail(i):
    inv=get_invoice(i);v=get_version(i);docs=rows('SELECT DISTINCT d.id,d.filename,v.version FROM versions v JOIN documents d ON d.id=v.document_id WHERE v.invoice_id=? ORDER BY v.version',(i,))
    return {'invoice':header(inv),'data':v['data'],'entries':v['entries'],'voucher':v['voucher'],'checks':get_checks(inv,v),'history':rows('SELECT timestamp,actor,action,reason,version FROM events WHERE invoice_id=? ORDER BY id DESC',(i,)),'documents':docs,'candidates':duplicates(inv,v),'versions':rows('SELECT version,created_at,source FROM versions WHERE invoice_id=? ORDER BY version DESC',(i,))}

def invalidate_export(inv):
    if inv.get('export_id'): DB.execute("UPDATE exports SET status='contains_superseded' WHERE id=?",(inv['export_id'],))
    DB.execute('UPDATE invoices SET export_id=NULL,approval_json=NULL WHERE id=?',(inv['id'],))

def new_version(inv,data,entries,voucher,doc,source,reason,actor):
    rev=inv['current_version']+1;invalidate_export(inv)
    DB.execute('INSERT INTO versions VALUES(?,?,?,?,?,?,?,?,?)',(inv['id'],rev,doc,jd(data),jd(entries),jd(voucher),source,now(),1))
    DB.execute("UPDATE invoices SET current_version=?,status='awaiting_approval',updated_at=? WHERE id=?",(rev,now(),inv['id']))
    event(inv['id'],actor,source,reason,rev);return rev

def edit_invoice(i,d,actor):
    inv=check_version(i,d)
    if inv['status'] in ('processing','manually_recorded','rejected_closed'): raise Problem('This invoice cannot be edited in its current status. Reopen a closed item first; recorded entries require separate correction follow-up.')
    reason=require_reason(d);old=get_version(i)
    supplied=d.get('data')
    if not isinstance(supplied,dict):raise Problem('Invoice data is required.')
    supplied={**supplied,'source_file':old['data'].get('source_file',inv['source_file']),'raw_text':old['data'].get('raw_text',''),'flags':[]}
    try:data=sanitize_data(supplied)
    except ValueError as e:raise Problem(str(e))
    entries=validate_entries_shape(d.get('entries',[]));voucher=validate_voucher_shape(d.get('voucher',{}))
    new_version(inv,data,entries,voucher,old['document_id'],'manual_correction',reason,actor)
    return detail(i)

def validate_entries_shape(entries):
    if not isinstance(entries,list) or len(entries)>150:raise Problem('Provide at most 150 accounting lines.')
    result=[]
    for e in entries:
        if not isinstance(e,dict):raise Problem('Invalid accounting line.')
        a={k:cleantext(e.get(k),1000 if k=='narration' else 180) for k in ('ledger','cost_centre','narration')}
        for k in ('debit','credit'):
            try:amount=Decimal(str(e.get(k) or 0))
            except Exception:raise Problem('Debit and credit must be numeric.')
            if not amount.is_finite() or abs(amount)>Decimal('9999999999999'):raise Problem('Invalid accounting amount.')
            a[k]=float(amount.quantize(Decimal('.01')))
        result.append(a)
    return result

def validate_voucher_shape(v):
    if not isinstance(v,dict):raise Problem('Voucher details are required.')
    return {k:cleantext(v.get(k),200) for k in ('company','voucher_type','voucher_date')}

def action_invoice(i,d,actor):
    inv=check_version(i,d);v=get_version(i);a=d.get('action');reason=cleantext(d.get('reason'),2000)
    if inv['status']=='processing':raise Problem('Finish or close the processing batch before reviewing this invoice.')
    if a=='record_correction_followup':
        if inv['status']!='manually_recorded':raise Problem('This action is for a manually recorded invoice.')
        event(i,actor,a,require_reason(d),inv['current_version']);return detail(i)
    if inv['status']=='manually_recorded':raise Problem('A manually recorded invoice cannot be changed or sent for ordinary entry again. Record a correction follow-up separately.')
    if a=='approve':
        if inv['status']=='rejected_closed':raise Problem('Reopen the invoice before approval.')
        if d.get('ledger_confirmed') is not True:raise Problem('Confirm that the company, ledger names and tax treatment were checked for manual Tally entry.')
        findings=get_checks(inv,v);blocked=[x for x in findings if x['severity']=='block']
        if blocked:raise Problem('Approval blocked: '+'; '.join(x['message'] for x in blocked))
        soft=[x['code'] for x in findings if x['severity']=='review'];accepted=d.get('exception_codes',[])
        if not isinstance(accepted,list) or not set(soft).issubset(set(accepted)):raise Problem('Explicitly accept every review exception, or correct it first.')
        if soft:reason=require_reason(d)
        if inv['status']!='approved_awaiting_entry':
            DB.execute("UPDATE invoices SET status='approved_awaiting_entry',updated_at=?,approval_json=? WHERE id=?",(now(),jd({'actor':actor,'at':now(),'version':inv['current_version'],'accepted':soft,'reason':reason,'ledger_confirmed':True}),i))
            event(i,actor,'approve',reason,inv['current_version'])
    elif a in ('hold','return','reject','reopen'):
        if inv['status']=='rejected_closed' and a!='reopen':raise Problem('Reopen the closed item before another decision.')
        if a=='reopen' and inv['status']!='rejected_closed':raise Problem('Only a closed item can be reopened.')
        reason=require_reason(d);invalidate_export(inv)
        status={'hold':'on_hold','return':'returned_for_correction','reject':'rejected_closed','reopen':'awaiting_approval'}[a]
        DB.execute('UPDATE invoices SET status=?,updated_at=? WHERE id=?',(status,now(),i));event(i,actor,a,reason,inv['current_version'])
    elif a=='mark_duplicate':
        reason=require_reason(d);target=d.get('duplicate_of')
        if target==i:raise Problem('Select a different original invoice.')
        t=get_invoice(target)
        if t['status']=='rejected_closed':raise Problem('The original invoice must remain active or recorded.')
        if target not in {x['id'] for x in duplicates(inv,v)}:raise Problem('Selected invoice is not a matching duplicate candidate. Use a documented rejection if it is otherwise invalid.')
        invalidate_export(inv);DB.execute("UPDATE invoices SET status='rejected_closed',updated_at=? WHERE id=?",(now(),i));event(i,actor,'duplicate_closed',f'Original {target}: {reason}',inv['current_version'])
    elif a=='link_replacement':
        reason=require_reason(d);donor=get_invoice(d.get('replacement_id'))
        if donor['id']==i or donor['status'] not in ('awaiting_approval','on_hold','returned_for_correction','processing_problem'):raise Problem('Choose an unapproved replacement invoice that has finished processing.')
        if inv['status']=='rejected_closed':raise Problem('Reopen the original before linking a replacement.')
        nv=get_version(donor['id']);new_version(inv,nv['data'],nv['entries'],nv['voucher'],nv['document_id'],'replacement_linked',f"Replacement {donor['id']}: {reason}",actor)
        invalidate_export(donor);DB.execute("UPDATE invoices SET status='rejected_closed',updated_at=? WHERE id=?",(now(),donor['id']));event(donor['id'],actor,'replacement_merged',f'History continues under {i}: {reason}',donor['current_version'])
    elif a=='mark_manual':
        if inv['status']!='approved_awaiting_entry':raise Problem('Only the approved current version can be marked manually recorded.')
        if any(x['severity']=='block' for x in get_checks(inv,v)):raise Problem('A blocking issue has arisen since approval. Resolve it before confirming manual entry.')
        manual={k:cleantext(d.get(k),200) for k in ('company','voucher_type','voucher_number','voucher_date')}
        if not all(manual.values()):raise Problem('Company, voucher type, voucher number and voucher date are required.')
        try:dt.date.fromisoformat(manual['voucher_date'])
        except ValueError:raise Problem('Use a valid YYYY-MM-DD voucher date.')
        if manual['company']!=v['voucher'].get('company'):raise Problem('The recorded Tally company must match the approved company.')
        for r in rows("SELECT id,manual_json FROM invoices WHERE status='manually_recorded'"):
            m=jl(r['manual_json'])
            if all(m.get(k)==manual[k] for k in ('company','voucher_type','voucher_number','voucher_date')):raise Problem(f"That voucher reference is already recorded against {r['id']}. Check it before continuing.")
        manual.update(actor=actor,recorded_at=now(),verification='User confirmation; not checked against Tally')
        DB.execute("UPDATE invoices SET status='manually_recorded',manual_json=?,updated_at=? WHERE id=?",(jd(manual),now(),i));event(i,actor,a,jd(manual),inv['current_version'])
    else:raise Problem('Unknown invoice action.')
    return detail(i)

def refresh_email_jobs():
    for job in rows("SELECT * FROM email_jobs WHERE status='queued'"):
        p=ROOT/'output/outlook'/('result_'+job['id']+'.json')
        if p.exists():
            try:
                r=json.loads(p.read_text(encoding='utf-8-sig'))
                if r.get('id')==job['id'] and r.get('status') in ('submitted','error','unknown'):
                    DB.execute('UPDATE email_jobs SET status=?,message=? WHERE id=?',(r['status'],cleantext(r.get('message'),2000),job['id']))
            except (ValueError,OSError):pass
        elif (dt.datetime.now(dt.timezone.utc)-dt.datetime.fromisoformat(job['created_at'])).total_seconds()>300:
            DB.execute("UPDATE email_jobs SET status='unknown',message=? WHERE id=?",('No receipt. Check Outlook and the helper before queuing another email.',job['id']))

def state(user,csrf):
    refresh_email_jobs();invs=rows('SELECT * FROM invoices ORDER BY created_at DESC,id DESC')
    counts={s:0 for s in STATUSES}
    for r in invs:counts[r['status']]+=1
    return {'user':user,'csrf':csrf,'settings':get_settings(),'counts':counts,'invoices':[header(i) for i in invs],
        'batches':rows('SELECT id,status,started_at,finished_at,received,new_count,duplicate_count,error_count,completed_count FROM batches ORDER BY started_at DESC'),
        'exports':rows('SELECT id,kind,filename,created_at,count,status FROM exports ORDER BY created_at DESC'),
        'backups':[{'filename':p.name,'created_at':dt.datetime.fromtimestamp(p.stat().st_mtime,dt.timezone.utc).isoformat()} for p in sorted((ROOT/'backups').glob('V2_Backup_*.zip'),reverse=True)],
        'ledgers':SUGGESTED_LEDGERS,
        'email_jobs':rows('SELECT id,status,message,created_at FROM email_jobs ORDER BY created_at DESC LIMIT 50')}

def next_id(prefix,table): return prefix+str(DB.execute(f'SELECT COUNT(*) FROM {table}').fetchone()[0]+1).zfill(6)
def start_batch(d):
    run=cleantext(d.get('runKey'),160)
    if not run:raise Problem('A unique runKey is required.')
    prior=row('SELECT * FROM batches WHERE run_key=?',(run,))
    if prior:
        files=[]
        if prior['status']=='processing':
            for rec in rows("SELECT * FROM receipts WHERE batch_id=? AND outcome IN ('new','retry')",(prior['id'],)):
                inv=get_invoice(rec['invoice_id']);v=get_version(inv['id'],rec['version'])
                if not v['extraction_received'] and inv['current_version']==rec['version']:
                    doc=row('SELECT * FROM documents WHERE id=?',(v['document_id'],));files.append(jobfile(inv,doc,rec['version']))
        return {'batch_id':prior['id'],'files':files,'received':prior['received'],'duplicate_count':prior['duplicate_count'],'idempotent':True}
    active=row("SELECT id FROM batches WHERE status='processing'")
    if active:raise Problem(f"Batch {active['id']} is still processing. Finish it or use Close interrupted batch in the review screen before a new run.",409)
    settings=get_settings()
    if d.get('companyName') and cleantext(d['companyName'],200)!=settings['companyName'] and DB.execute('SELECT COUNT(*) FROM invoices').fetchone()[0]:
        raise Problem('This V2 workspace already contains invoices for '+settings['companyName']+'. Keep the same company in Demo Settings; use a separate workspace for another company.')
    for k in ('model','companyName','asOfDate'):
        if d.get(k):settings[k]=cleantext(d[k],200)
    try:dt.date.fromisoformat(settings['asOfDate'])
    except ValueError:raise Problem('Invalid asOfDate; use YYYY-MM-DD.')
    DB.execute('UPDATE settings SET value=? WHERE key=?',(jd(settings),'settings'))
    b='B'+dt.datetime.now(dt.timezone.utc).strftime('%Y%m%d')+'_'+secrets.token_hex(3).upper()
    opening=[]
    for previous in rows("SELECT * FROM invoices WHERE status NOT IN ('manually_recorded','rejected_closed')"):
        old_data=get_version(previous['id'])['data']
        opening.append({'id':previous['id'],'status':previous['status'],'invoice_total':old_data.get('invoice_total'),'currency':old_data.get('currency')})
    DB.execute('INSERT INTO batches(id,run_key,status,started_at,opening_json,config_json) VALUES(?,?,?,?,?,?)',(b,run,'processing',now(),jd(opening),jd(settings)))
    files=[];received=0;new=0;dups=0;errs=0
    for p in sorted((ROOT/'input').iterdir(),key=lambda x:x.name.lower()):
        if p.suffix.lower()!='.pdf' or not p.is_file():continue
        received+=1
        try:
            if p.is_symlink():raise ValueError('Symbolic-link input files are not accepted.')
            if p.stat().st_size>25*1024*1024:raise ValueError('PDF exceeds the 25 MB per-file limit.')
            raw=p.read_bytes()
            if not raw.startswith(b'%PDF-'):raise ValueError('File does not start with a PDF header.')
            digest=hashlib.sha256(raw).hexdigest();doc=row('SELECT * FROM documents WHERE sha256=?',(digest,))
            if doc:
                inv=get_invoice(doc['invoice_id']);cur=get_version(inv['id'])
                # A document merged into another record remains a duplicate receipt, not a new invoice.
                if inv['status']=='processing_problem' and cur['document_id']==doc['id']:
                    rev=inv['current_version']+1
                    DB.execute('INSERT INTO versions VALUES(?,?,?,?,?,?,?,?,?)',(inv['id'],rev,doc['id'],jd({'source_file':p.name,'flags':[]}),jd([]),jd(suggest_voucher({},settings['companyName'])),'retry_pending',now(),0))
                    DB.execute("UPDATE invoices SET current_version=?,status='processing',updated_at=? WHERE id=?",(rev,now(),inv['id']))
                    files.append(jobfile(inv,doc,rev));outcome='retry';event(inv['id'],'n8n','retry_registered','Retry failed extraction',rev,b)
                else:dups+=1;rev=inv['current_version'];outcome='duplicate_file'
                DB.execute('INSERT INTO receipts(batch_id,invoice_id,version,filename,outcome) VALUES(?,?,?,?,?)',(b,inv['id'],rev,p.name,outcome));continue
            i=next_id('INV-', 'invoices');docid='DOC-'+secrets.token_hex(8);arch=digest+'.pdf';archive=ROOT/'archive'/arch
            if not archive.exists():
                tmp=archive.with_suffix('.tmp');tmp.write_bytes(raw);os.replace(tmp,archive)
            DB.execute('INSERT INTO invoices(id,batch_id,source_file,current_version,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?)',(i,b,p.name,1,'processing',now(),now()))
            DB.execute('INSERT INTO documents VALUES(?,?,?,?,?,?)',(docid,i,p.name,digest,arch,now()))
            DB.execute('INSERT INTO versions VALUES(?,?,?,?,?,?,?,?,?)',(i,1,docid,jd({'source_file':p.name,'flags':[]}),jd([]),jd(suggest_voucher({},settings['companyName'])),'extraction_pending',now(),0))
            DB.execute('INSERT INTO receipts(batch_id,invoice_id,version,filename,outcome) VALUES(?,?,?,?,?)',(b,i,1,p.name,'new'))
            event(i,'n8n','received','Original file archived before extraction',1,b);new+=1
            files.append(jobfile(get_invoice(i),row('SELECT * FROM documents WHERE id=?',(docid,)),1))
        except (OSError,ValueError) as e:
            errs+=1;DB.execute('INSERT INTO receipts(batch_id,filename,outcome,error) VALUES(?,?,?,?)',(b,p.name,'file_error',str(e)))
    DB.execute('UPDATE batches SET received=?,new_count=?,duplicate_count=?,error_count=? WHERE id=?',(received,new,dups,errs,b))
    return {'batch_id':b,'files':files,'received':received,'duplicate_count':dups}

def jobfile(inv,doc,rev):
    return {'invoice_id':inv['id'],'version_id':rev,'source_file':doc['filename'],'archive_path':N8N_PREFIX+'/archive/'+doc['archive_name'],'sha256':doc['sha256']}

def ingest_result(d):
    i=d.get('invoice_id');b=d.get('batch_id');rev=d.get('version_id');inv=get_invoice(i);v=get_version(i,rev)
    receipt=row("SELECT * FROM receipts WHERE batch_id=? AND invoice_id=? AND version=? AND outcome IN ('new','retry','extracted','extraction_error')",(b,i,rev))
    if not receipt:raise Problem('This invoice version is not registered in that batch.',409)
    if v['extraction_received']:return {'ok':True,'status':inv['status'],'invoice_id':i,'idempotent':True}
    batch=row('SELECT * FROM batches WHERE id=?',(b,))
    if not batch or batch['status']!='processing' or inv['current_version']!=rev or inv['status']!='processing':raise Problem('This batch or invoice version is no longer accepting extraction results.',409)
    raw=d.get('data',{})
    DB.execute('INSERT INTO extraction_payloads VALUES(?,?,?,?)',(i,rev,jd(raw),now()))
    try:data=sanitize_data(raw)
    except (ValueError,TypeError) as e:data={'source_file':inv['source_file'],'flags':['LLM_EXTRACTION_ERROR'],'notes':'Invalid extraction: '+str(e)}
    data['source_file']=inv['source_file']
    # Presence checks corroborate copied facts; they do not prove correct labels.
    source=data.get('raw_text') or ''
    if source:
        normalized=re.sub('[^A-Z0-9]','',source.upper())
        absent=any(data.get(k) and re.sub('[^A-Z0-9]','',str(data[k]).upper()) not in normalized for k in ('invoice_number','supplier_gstin'))
        numbers=[]
        for token in re.findall(r'-?\d[\d,]*\.?\d*',source):
            with contextlib.suppress(Exception):numbers.append(Decimal(token.replace(',','')))
        for k in ('taxable_value','cgst','sgst','igst','other_charges','round_off','invoice_total'):
            if data.get(k) is not None and not any(abs(Decimal(str(data[k]))-n)<Decimal('.005') for n in numbers):absent=True
        if absent and 'SOURCE_MISMATCH' not in data.setdefault('flags',[]):data['flags'].append('SOURCE_MISMATCH')
    conf=jl(batch['config_json']);entries=suggest_entries(data);voucher=suggest_voucher(data,conf['companyName'])
    bad=any(x in ('LLM_EXTRACTION_ERROR','PDF_READ_ERROR','NO_READABLE_TEXT') for x in data.get('flags',[]))
    status='processing_problem' if bad else 'awaiting_approval'
    DB.execute('UPDATE versions SET data_json=?,entries_json=?,voucher_json=?,source=?,extraction_received=1 WHERE invoice_id=? AND version=?',(jd(data),jd(entries),jd(voucher),'qwen_extraction',i,rev))
    DB.execute('UPDATE invoices SET status=?,updated_at=? WHERE id=?',(status,now(),i))
    DB.execute('UPDATE receipts SET outcome=? WHERE id=?',('extraction_error' if bad else 'extracted',receipt['id']))
    event(i,'n8n','extraction_saved','Requires human review',rev,b)
    current=get_invoice(i)
    for match in duplicates(current,get_version(i)):
        other=get_invoice(match['id'])
        if other['status']=='approved_awaiting_entry':
            invalidate_export(other)
            DB.execute("UPDATE invoices SET status='awaiting_approval',updated_at=? WHERE id=?",(now(),other['id']))
            event(other['id'],'system','approval_reopened','New duplicate candidate '+i+' requires resolution before entry.',other['current_version'],b)
    return {'ok':True,'status':status,'invoice_id':i}

def finish_batch(b,reason='',interrupted=False):
    batch=row('SELECT * FROM batches WHERE id=?',(b,))
    if not batch:raise Problem('Batch not found.',404)
    if batch['status']!='processing':return {'batch_id':b,'status':batch['status'],'idempotent':True,'url':'http://localhost:'+str(PORT)}
    for r in rows("SELECT * FROM receipts WHERE batch_id=? AND outcome IN ('new','retry')",(b,)):
        inv=get_invoice(r['invoice_id']);v=get_version(inv['id'],r['version'])
        if inv['current_version']==r['version'] and not v['extraction_received']:
            data=v['data'];data['flags']=['LLM_EXTRACTION_ERROR'];data['notes']='No extraction result; batch interrupted or ended early.'
            DB.execute('UPDATE versions SET data_json=?,source=?,extraction_received=1 WHERE invoice_id=? AND version=?',(jd(data),'interrupted_extraction',inv['id'],r['version']))
            DB.execute("UPDATE invoices SET status='processing_problem',updated_at=? WHERE id=?",(now(),inv['id']))
            event(inv['id'],'system','processing_failed',reason or data['notes'],r['version'],b)
        DB.execute("UPDATE receipts SET outcome='extraction_error',error=? WHERE id=?",(reason or 'No extraction result',r['id']))
    errors=DB.execute("SELECT COUNT(*) FROM receipts WHERE batch_id=? AND outcome IN ('file_error','extraction_error')",(b,)).fetchone()[0]
    completed=DB.execute("SELECT COUNT(*) FROM receipts WHERE batch_id=? AND outcome='extracted'",(b,)).fetchone()[0]
    status='interrupted' if interrupted else ('partly_completed' if errors else 'completed')
    DB.execute('UPDATE batches SET status=?,finished_at=?,error_count=?,completed_count=? WHERE id=?',(status,now(),errors,completed,b))
    event(None,'system','batch_'+status,reason,None,b)
    report=make_export({'kind':'batch','batch_id':b},'n8n');outstanding=make_export({'kind':'outstanding'},'n8n')
    return {'batch_id':b,'status':status,'summary':{'received':batch['received'],'new':batch['new_count'],'duplicates':batch['duplicate_count'],'extracted':completed,'errors':errors},'reports':[report,outstanding],'url':'http://localhost:'+str(PORT)}

def invoice_report_row(inv):
    v=get_version(inv['id']);d=v['data'];m=jl(inv.get('manual_json'));a=jl(inv.get('approval_json'));find=get_checks(inv,v)
    source_url='http://localhost:'+str(PORT)+'/api/documents/'+v['document_id'] if v.get('document_id') else ''
    decision=row("SELECT action,actor,reason,timestamp FROM events WHERE invoice_id=? AND actor<>'n8n' AND action NOT IN ('issued_for_manual_entry','export_released') ORDER BY id DESC LIMIT 1",(inv['id'],)) or {}
    age=max(0,(dt.datetime.now(dt.timezone.utc)-dt.datetime.fromisoformat(inv['created_at'])).days)
    return [inv['id'],inv['current_version'],inv['batch_id'],d.get('supplier_name'),d.get('invoice_number'),d.get('invoice_date'),d.get('due_date'),d.get('currency'),d.get('taxable_value'),d.get('cgst'),d.get('sgst'),d.get('igst'),d.get('other_charges'),d.get('round_off'),d.get('invoice_total'),inv['status'],' | '.join(x['message'] for x in find),d.get('source_file') or inv['source_file'],a.get('actor'),a.get('at'),a.get('reason'),inv.get('export_id'),m.get('company'),m.get('voucher_number'),m.get('voucher_date'),m.get('verification'),source_url,age,decision.get('action'),decision.get('reason'),decision.get('actor'),decision.get('timestamp')]
REPORT_HEADERS=['Invoice ID','Version','Original batch','Supplier','Invoice number','Invoice date','Due date','Currency','Taxable value','CGST','SGST','IGST','Other charges','Round off','Invoice total','Status','Review findings','Source filename','Approved by','Approved at UTC','Approval remarks','Export ID','Tally company','Voucher number','Voucher date','Posting confirmation','Source PDF URL (sign in first)','Days since receipt','Latest decision','Latest decision reason','Decision by','Decision at UTC']

def status_report(chosen):
    groups={}
    for inv in chosen:
        data=get_version(inv['id'])['data'];key=(inv['status'],data.get('currency') or 'Unknown')
        g=groups.setdefault(key,[0,Decimal('0'),0]);g[0]+=1
        if data.get('invoice_total') is None:g[2]+=1
        else:g[1]+=Decimal(str(data['invoice_total']))
    return {'name':'Status Totals','headers':['Status','Currency','Invoice count','Known invoice total','Amounts not extracted'],
        'rows':[[*key,count,float(amount),missing] for key,(count,amount,missing) in sorted(groups.items())]}

def line_report(chosen):
    result=[]
    for inv in chosen:
        v=get_version(inv['id']);data=v['data']
        for number,line in enumerate(data.get('line_items',[]),1):
            result.append([inv['id'],inv['current_version'],data.get('supplier_name'),data.get('invoice_number'),number,line.get('description'),line.get('quantity'),line.get('unit_price'),line.get('taxable_amount'),data.get('currency')])
    return {'name':'Invoice Line Items','headers':['Invoice ID','Version','Supplier','Invoice number','Line','Description','Quantity','Unit price','Taxable amount','Currency'],'rows':result}

def make_export(d,actor):
    kind=d.get('kind');stamp=dt.datetime.now(dt.timezone.utc).strftime('%Y%m%d_%H%M%S');eid='EX-'+stamp+'-'+secrets.token_hex(3);snap=[];sheets=[]
    if kind=='approved':
        chosen=rows("SELECT * FROM invoices WHERE status='approved_awaiting_entry' AND export_id IS NULL ORDER BY id")
        if not chosen:raise Problem('No approved, unissued invoices. Re-download an existing export, or release its unrecorded items with a reason.')
        blocked=[]
        for i in chosen:
            v=get_version(i['id']);found=get_checks(i,v);approval=jl(i['approval_json']);remaining=[x for x in found if x['severity']=='block' or x['code'] not in approval.get('accepted',[])]
            if remaining:blocked.append(i['id'])
        if blocked:raise Problem('Resolve new or unaccepted issues before export: '+', '.join(blocked))
        entryrows=[]
        for i in chosen:
            v=get_version(i['id']);snap.append({'id':i['id'],'version':i['current_version']})
            for n,e in enumerate(v['entries'],1):entryrows.append([i['id'],i['current_version'],v['voucher'].get('company'),v['voucher'].get('voucher_type'),v['voucher'].get('voucher_date'),v['data'].get('invoice_number'),v['data'].get('due_date'),n,e.get('ledger'),e.get('debit'),e.get('credit'),e.get('cost_centre'),e.get('narration')])
        sheets=[{'name':'Approved Invoices','headers':REPORT_HEADERS,'rows':[invoice_report_row(i) for i in chosen]}, {'name':'Accounting Entries','headers':['Invoice ID','Version','Tally company','Voucher type','Voucher date','Bill reference','Due date','Line','Ledger','Debit INR','Credit INR','Cost centre','Narration'],'rows':entryrows}]
        title='Approved_Entries'
    elif kind=='outstanding':
        chosen=rows("SELECT * FROM invoices WHERE status NOT IN ('manually_recorded','rejected_closed') ORDER BY created_at")
        sheets=[{'name':'Outstanding','headers':REPORT_HEADERS,'rows':[invoice_report_row(i) for i in chosen]}];title='Outstanding_Invoices';snap=[{'id':i['id'],'version':i['current_version']} for i in chosen]
    elif kind=='batch':
        b=row('SELECT * FROM batches WHERE id=?',(d.get('batch_id'),))
        if not b:raise Problem('Choose a valid batch.')
        rec=rows('SELECT * FROM receipts WHERE batch_id=? ORDER BY id',(b['id'],));opening=jl(b['opening_json'],[])
        sheets=[{'name':'Batch Summary','headers':['Measure','Value'],'rows':[['Batch ID',b['id']],['Status',b['status']],['Started UTC',b['started_at']],['Finished UTC',b['finished_at']],['Opening outstanding invoices',len(opening)],['Files received',b['received']],['New invoice records',b['new_count']],['Repeated files skipped',b['duplicate_count']],['Successful extractions',b['completed_count']],['Processing errors',b['error_count']],['Current outstanding invoices',DB.execute("SELECT COUNT(*) FROM invoices WHERE status NOT IN ('manually_recorded','rejected_closed')").fetchone()[0]],['Note','Counts distinguish file receipts and unique invoices; corrected versions do not create new liabilities.']]}, {'name':'File Receipts','headers':['Filename','Invoice ID','Version','Processing outcome','Error','Current status'],'rows':[[r['filename'],r['invoice_id'],r['version'],r['outcome'],r['error'],get_invoice(r['invoice_id'])['status'] if r['invoice_id'] else 'file_error'] for r in rec]}, {'name':'Opening Outstanding','headers':['Invoice ID','Status at batch start','Currency','Invoice total'],'rows':[[x['id'],x['status'],x.get('currency'),x.get('invoice_total')] for x in opening]}]
        snap=[{'id':r['invoice_id'],'version':r['version']} for r in rec if r['invoice_id']];title='Batch_Summary_'+b['id']
        chosen=[get_invoice(i) for i in dict.fromkeys(r['invoice_id'] for r in rec if r['invoice_id'])]
        sheets.append({'name':'Current Invoice Register','headers':REPORT_HEADERS,'rows':[invoice_report_row(i) for i in chosen]})
    else:raise Problem('Unknown report kind.')
    sheets.append({'name':'Read Me','headers':['Item','Explanation'],'rows':[['Export ID',eid],['Generated UTC',now()],['Kind',kind],['Use','Manual entry reference; not a Tally import file. Check exact ledger names and company.'],['Snapshot','Approval applies only to exported versions. Check current dashboard before entry. Superseded files must not be used.'],['Posting','Exporting does not record a Tally voucher. Mark manually recorded after entry.'],['Taxes','Tax lines are proposed accounting treatment reviewed by you; no automatic ITC or tax compliance determination.']]})
    sheets.extend([status_report(chosen),line_report(chosen)])
    filename='V2_'+title+'_'+stamp+'_'+secrets.token_hex(2)+'.xlsx';target=ROOT/'output'/filename
    write_xlsx(target,sheets)
    DB.execute('INSERT INTO exports VALUES(?,?,?,?,?,?,?)',(eid,kind,filename,now(),len(snap),'current',jd(snap)))
    if kind=='approved':
        for x in snap:
            DB.execute('INSERT INTO export_items VALUES(?,?,?)',(eid,x['id'],x['version']))
            DB.execute('UPDATE invoices SET export_id=?,updated_at=? WHERE id=?',(eid,now(),x['id']))
            event(x['id'],actor,'issued_for_manual_entry',eid,x['version'])
    event(None,actor,'export_created',eid+' '+kind)
    return {'id':eid,'kind':kind,'filename':filename,'url':'/api/exports/'+eid+'/download','count':len(snap),'status':'current'}

def release_export(eid,d,actor):
    exp=row('SELECT * FROM exports WHERE id=?',(eid,))
    if not exp or exp['kind']!='approved':raise Problem('Choose an approved-entry export.')
    reason=require_reason(d)
    for i in rows("SELECT * FROM invoices WHERE export_id=? AND status<>'manually_recorded'",(eid,)):
        DB.execute('UPDATE invoices SET export_id=NULL,updated_at=? WHERE id=?',(now(),i['id']));event(i['id'],actor,'export_released',eid+': '+reason,i['current_version'])
    DB.execute("UPDATE exports SET status='released' WHERE id=?",(eid,));return {'ok':True}

def queue_email(eid,d,actor):
    exp=row('SELECT * FROM exports WHERE id=?',(eid,))
    if not exp:raise Problem('Export not found.',404)
    if exp['status']!='current':raise Problem('This export is released or superseded. Create a current report.')
    if exp['kind']=='approved':
        for item in jl(exp['snapshot_json'],[]):
            inv=get_invoice(item['id']);v=get_version(inv['id']);approval=jl(inv.get('approval_json'))
            invalid=(inv['current_version']!=item['version'] or inv['status']!='approved_awaiting_entry' or inv['export_id']!=eid)
            findings=get_checks(inv,v)
            invalid=invalid or any(x['severity']=='block' or x['code'] not in approval.get('accepted',[]) for x in findings)
            if invalid:raise Problem('This approved snapshot is no longer ready for entry. Review '+inv['id']+' and generate a current report.')
    def addresses(value):
        a=list(dict.fromkeys(x.strip() for x in re.split('[;,]',str(value or '')) if x.strip()))
        if any(not re.fullmatch(r'[^\s@<>;,]+@[^\s@<>;,]+\.[^\s@<>;,]+',x) for x in a):raise Problem('Use plain email addresses separated by semicolons.')
        return a
    sender=addresses(d.get('sender'));to=addresses(d.get('to'));cc=addresses(d.get('cc'))
    if len(sender)!=1 or not to or len(to)+len(cc)>50:raise Problem('Enter one sender and 1 to 50 recipient addresses.')
    import html
    jobid='MAIL-'+secrets.token_hex(8);folder=ROOT/'output/outlook';attachment=jobid+'_'+exp['filename'];shutil.copyfile(ROOT/'output'/exp['filename'],folder/attachment)
    body='email_'+jobid+'.html';bodytext=f'<!doctype html><html><meta charset="utf-8"><body style="font:15px Arial;line-height:1.6"><h2>Invoice approval and tracking — V2</h2><p>Report: {html.escape(exp["kind"])}</p><p>Export reference: {html.escape(eid)}<br>Generated: {html.escape(exp["created_at"])} UTC<br>Records: {exp["count"]}</p><p>The attached workbook contains the selected report snapshot. Approved entries are for manual recording in Tally after checking the latest invoice version and company/ledger names. Outstanding invoices remain held for action. Exporting does not mean that entries have been recorded in Tally.</p><p>Approval status and later corrections are available in your local approval application. This report does not establish payment status or tax credit eligibility.</p></body></html>'
    (folder/body).write_text(bodytext,encoding='utf-8')
    job={'schemaVersion':2,'id':jobid,'sender':sender[0],'to':to,'cc':cc,'subject':'V2 Invoice '+exp['kind']+' | '+eid,'body_file':body,'attachments':[attachment],'expiresAtUtc':(dt.datetime.now(dt.timezone.utc)+dt.timedelta(seconds=180)).isoformat()}
    temporary=folder/('job_'+jobid+'.tmp');temporary.write_text(jd(job),encoding='utf-8');os.replace(temporary,folder/('job_'+jobid+'.json'))
    DB.execute('INSERT INTO email_jobs VALUES(?,?,?,?,?)',(jobid,eid,'queued','Waiting for V2 Windows Outlook helper',now()));event(None,actor,'email_queued',f'{jobid} export {eid} to '+ '; '.join(to+cc))
    return {'status':'queued','job_id':jobid}

def create_backup():
    stamp=dt.datetime.now(dt.timezone.utc).strftime('%Y%m%d_%H%M%S');name='V2_Backup_'+stamp+'_'+secrets.token_hex(2)+'.zip';target=ROOT/'backups'/name
    with tempfile.TemporaryDirectory(dir=DATA) as temp:
        snapshot=Path(temp)/'invoice_control_v2.db';dest=sqlite3.connect(snapshot)
        # Caller owns service lock; separate connection prevents backup of an open write transaction.
        source=sqlite3.connect(DATA/'invoice_control_v2.db');source.backup(dest);source.close();dest.close()
        files=[snapshot]+[p for sub in ('archive','output') for p in (ROOT/sub).rglob('*') if p.is_file() and not p.is_symlink() and p.suffix!='.tmp']
        manifest={'version':VERSION,'created_at':now(),'files':{}}
        with zipfile.ZipFile(target.with_suffix('.tmp'),'w',zipfile.ZIP_DEFLATED) as z:
            for p in files:
                rel='database/invoice_control_v2.db' if p==snapshot else p.relative_to(ROOT).as_posix();raw=p.read_bytes();z.writestr(rel,raw);manifest['files'][rel]=hashlib.sha256(raw).hexdigest()
            z.writestr('manifest.json',jd(manifest))
        os.replace(target.with_suffix('.tmp'),target)
    return {'filename':name,'url':'/api/backups/'+name+'/download'}

def restore_backup(path,confirm):
    if not confirm:raise Problem('Restore requires --confirm-replace.')
    p=Path(path).resolve()
    if not p.is_file():raise Problem('Backup ZIP not found.')
    with zipfile.ZipFile(p) as z:
        if z.testzip():raise Problem('The backup ZIP is damaged.')
        try:manifest=json.loads(z.read('manifest.json'))
        except Exception:raise Problem('No valid V2 backup manifest.')
        expected=set(manifest.get('files',{}))
        if 'database/invoice_control_v2.db' not in expected or set(z.namelist())!=expected|{'manifest.json'}:raise Problem('Backup contents do not match its manifest.')
        if sum(i.file_size for i in z.infolist())>2*1024**3:raise Problem('Backup exceeds the 2 GB restore limit.')
        with tempfile.TemporaryDirectory(dir=DATA) as temp:
            temp=Path(temp)
            for name,digest in manifest['files'].items():
                parts=Path(name).parts
                if name.startswith(('/', '\\')) or '..' in parts or '\\' in name or ':' in name or not (name=='database/invoice_control_v2.db' or name.startswith(('archive/','output/'))):raise Problem('Unsafe backup path.')
                raw=z.read(name)
                if hashlib.sha256(raw).hexdigest()!=digest:raise Problem('Backup digest check failed for '+name)
                dest=temp/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
            test=sqlite3.connect(temp/'database/invoice_control_v2.db')
            if test.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise Problem('Database integrity check failed.')
            tables={x[0] for x in test.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            if not {'invoices','versions','events','exports'}.issubset(tables):raise Problem('Not an invoice V2 database.')
            # Pending Outlook jobs are quarantined on restore; never resend restored mail automatically.
            test.execute("UPDATE email_jobs SET status='unknown',message='Restored backup; check Outlook before any new email.' WHERE status='queued'");test.commit();test.close()
            if (DATA/'invoice_control_v2.db').exists():
                init_db();old=create_backup();DB.close();print('Pre-restore backup:',old['filename'])
            for sub in ('archive','output'):
                target=ROOT/sub
                if target.exists():shutil.rmtree(target)
                source=temp/sub
                if source.exists():shutil.copytree(source,target)
                else:target.mkdir(parents=True)
            outlook=ROOT/'output/outlook';outlook.mkdir(exist_ok=True)
            for job in outlook.glob('job_*.json'):job.rename(job.with_suffix('.restored'))
            for ext in ('-wal','-shm'):
                with contextlib.suppress(FileNotFoundError):(DATA/('invoice_control_v2.db'+ext)).unlink()
            os.replace(temp/'database/invoice_control_v2.db',DATA/'invoice_control_v2.db')
    print('Restore completed. Source invoices and history restored. Pending email jobs were not requeued.')

class Handler(BaseHTTPRequestHandler):
    server_version='InvoiceApprovalV2'
    def log_message(self,fmt,*args): logging.info('%s %s',self.command,self.path.split('?')[0])
    def json_response(self,value,status=200,headers=None):
        payload=jd(value).encode();self.send_response(status)
        for k,v in (headers or {}).items():self.send_header(k,v)
        self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(payload)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(payload)
    def read_json(self):
        n=int(self.headers.get('Content-Length','0'))
        if n<0 or n>4*1024*1024:raise Problem('Request is too large.',413)
        if not self.headers.get('Content-Type','').lower().startswith('application/json'):raise Problem('Use application/json requests.',415)
        try:r=json.loads(self.rfile.read(n))
        except Exception:raise Problem('Invalid JSON.')
        if not isinstance(r,dict):raise Problem('Expected a JSON object.')
        return r
    def session(self):
        cookie=http.cookies.SimpleCookie()
        try:cookie.load(self.headers.get('Cookie',''));key=cookie.get('invoice_v2_session');key=key.value if key else ''
        except Exception:key=''
        s=SESSIONS.get(key)
        if not s or s['expires']<time.time():raise Problem('Please sign in.',401)
        return key,s
    def authenticate(self,path,post=False):
        if path.startswith('/api/ingest/'):
            if not TOKEN or not hmac.compare_digest(self.headers.get('Authorization',''),'Bearer '+TOKEN):raise Problem('Invalid workflow API token.',401)
            return 'n8n',None
        key,s=self.session()
        if post and not hmac.compare_digest(self.headers.get('X-CSRF-Token',''),s['csrf']):raise Problem('Session changed. Refresh the page and try again.',403)
        return s['user'],s
    def file_response(self,path,filename=None,mime=None):
        if not path.is_file():raise Problem('File not found.',404)
        self.send_response(200);self.send_header('Content-Type',mime or mimetypes.guess_type(str(path))[0] or 'application/octet-stream');self.send_header('Content-Length',str(path.stat().st_size));self.send_header('X-Content-Type-Options','nosniff');self.send_header('Cache-Control','no-store');self.send_header('Referrer-Policy','no-referrer')
        if filename:self.send_header('Content-Disposition',"attachment; filename*=UTF-8''"+urllib.parse.quote(filename,safe=''))
        self.end_headers()
        with path.open('rb') as f:shutil.copyfileobj(f,self.wfile)
    def do_GET(self): self.dispatch(False)
    def do_POST(self): self.dispatch(True)
    def dispatch(self,post):
        try:
            path=urllib.parse.unquote(urllib.parse.urlsplit(self.path).path)
            if path=='/api/health':return self.json_response({'ok':True,'version':VERSION})
            if not post and path in ('/','/index.html','/style.css','/app.js','/static/style.css','/static/app.js'):
                return self.file_response(Path(__file__).parent/'static'/('index.html' if path=='/' else path.rsplit('/',1)[-1]))
            d=self.read_json() if post else {}
            with LOCK:
                if path=='/api/login' and post:
                    key=self.client_address[0];attempts=[t for t in LOGIN_ATTEMPTS.get(key,[]) if time.time()-t<300]
                    if len(attempts)>=10:raise Problem('Too many sign-in attempts. Try again in five minutes.',429)
                    if not hmac.compare_digest(str(d.get('username','')),USER) or not hmac.compare_digest(str(d.get('password','')),PASSWORD):
                        LOGIN_ATTEMPTS[key]=attempts+[time.time()];raise Problem('Incorrect username or password.',401)
                    LOGIN_ATTEMPTS.pop(key,None);token=secrets.token_urlsafe(32);s={'user':USER,'csrf':secrets.token_urlsafe(24),'expires':time.time()+8*3600};SESSIONS[token]=s
                    return self.json_response({'user':USER,'csrf':s['csrf']},headers={'Set-Cookie':'invoice_v2_session='+token+'; Path=/; HttpOnly; SameSite=Strict; Max-Age=28800'})
                actor,session=self.authenticate(path,post)
                if path=='/api/logout' and post:
                    key,_=self.session();SESSIONS.pop(key,None);return self.json_response({'ok':True},headers={'Set-Cookie':'invoice_v2_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0'})
                if path=='/api/backup' and post:
                    DB.commit();result=create_backup();event(None,actor,'backup_created',result['filename']);DB.commit();return self.json_response(result)
                with DB:
                    if path=='/api/state' and not post:result=state(actor,session['csrf'])
                    elif path=='/api/ingest/start' and post:result=start_batch(d)
                    elif path=='/api/ingest/result' and post:result=ingest_result(d)
                    elif path=='/api/ingest/finish' and post:result=finish_batch(d.get('batch_id'))
                    elif (m:=re.fullmatch(r'/api/invoices/(INV-\d+)',path)) and not post:result=detail(m[1])
                    elif (m:=re.fullmatch(r'/api/invoices/(INV-\d+)/edit',path)) and post:result=edit_invoice(m[1],d,actor)
                    elif (m:=re.fullmatch(r'/api/invoices/(INV-\d+)/action',path)) and post:result=action_invoice(m[1],d,actor)
                    elif (m:=re.fullmatch(r'/api/versions/(INV-\d+)/(\d+)',path)) and not post:result=version_history(m[1],int(m[2]))
                    elif (m:=re.fullmatch(r'/api/batches/([A-Za-z0-9_-]+)/close',path)) and post:result=finish_batch(m[1],require_reason(d),True)
                    elif path=='/api/exports' and post:result=make_export(d,actor)
                    elif (m:=re.fullmatch(r'/api/exports/([A-Za-z0-9_-]+)/release',path)) and post:result=release_export(m[1],d,actor)
                    elif (m:=re.fullmatch(r'/api/exports/([A-Za-z0-9_-]+)/email',path)) and post:result=queue_email(m[1],d,actor)
                    elif (m:=re.fullmatch(r'/api/exports/([A-Za-z0-9_-]+)/download',path)) and not post:
                        e=row('SELECT * FROM exports WHERE id=?',(m[1],))
                        if not e:raise Problem('Export not found.',404)
                        return self.file_response(ROOT/'output'/e['filename'],e['filename'])
                    elif (m:=re.fullmatch(r'/api/documents/(DOC-[a-f0-9]+)',path)) and not post:
                        doc=row('SELECT * FROM documents WHERE id=?',(m[1],))
                        if not doc:raise Problem('Document not found.',404)
                        return self.file_response(ROOT/'archive'/doc['archive_name'],mime='application/pdf')
                    elif (m:=re.fullmatch(r'/api/backups/(V2_Backup_[A-Za-z0-9_-]+\.zip)/download',path)) and not post:return self.file_response(ROOT/'backups'/m[1],m[1])
                    else:raise Problem('Endpoint not found.',404)
                self.json_response(result)
        except Problem as e:self.json_response({'error':e.message},e.status)
        except (ValueError,TypeError,KeyError) as e:self.json_response({'error':'Invalid request: '+str(e)},400)
        except (BrokenPipeError,ConnectionResetError):pass
        except Exception:
            logging.exception('Request failed');self.json_response({'error':'The local service encountered an error. Check the application log; the decision was not committed.'},500)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--restore');ap.add_argument('--confirm-replace',action='store_true');args=ap.parse_args()
    DATA.mkdir(parents=True,exist_ok=True)
    import fcntl
    guard=(DATA/'service.lock').open('a')
    try:fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:raise SystemExit('The approval service is running. Stop only V2 before starting another service or restoring.')
    if args.restore:
        for sub in ('archive','output','backups'):(ROOT/sub).mkdir(parents=True,exist_ok=True)
        restore_backup(args.restore,args.confirm_replace);return
    if len(TOKEN)<24 or len(PASSWORD)<12:raise SystemExit('Run the setup script first. A workflow token (24+ characters) and reviewer password (12+ characters) are required.')
    init_db();logging.basicConfig(level=logging.INFO,format='%(asctime)s %(message)s')
    print('Invoice Approval V2 listening on port',PORT,flush=True)
    try:ThreadingHTTPServer(('0.0.0.0',PORT),Handler).serve_forever()
    finally:DB.close()
if __name__=='__main__':main()
