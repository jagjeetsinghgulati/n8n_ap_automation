"""Small dependency-free XLSX exporter for immutable invoice report snapshots.

The caller supplies already reviewed report values. All text is stored as an
inline string: invoice references or supplier text beginning with '=', '+', '-'
or '@' can never become executable workbook formulas or external links.
"""
from __future__ import annotations

from datetime import date, datetime, timezone
from decimal import Decimal
from math import ceil, isfinite
from pathlib import Path
import os
import re
import tempfile
from xml.sax.saxutils import escape, quoteattr
from zipfile import ZipFile, ZIP_DEFLATED


_NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
_REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
_XML_DECL = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
_BAD_XML = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\ud800-\udfff\ufffe\uffff]")
_BAD_SHEET = re.compile(r"[\[\]:*?/\\]")


def _text(value):
    return _BAD_XML.sub("", str(value))


def _col(number):
    label = ""
    while number:
        number, remainder = divmod(number - 1, 26)
        label = chr(65 + remainder) + label
    return label


def _date_value(value):
    """Convert an ISO-compatible Python date to Excel's 1900 date system."""
    if isinstance(value, datetime):
        if value.tzinfo:
            value = value.astimezone(timezone.utc).replace(tzinfo=None)
    else:
        value = datetime.combine(value, datetime.min.time())
    # The fictitious 1900-02-29 is Excel day 60.
    result = (value - datetime(1899, 12, 31)).total_seconds() / 86400
    return result + (1 if value >= datetime(1900, 3, 1) else 0)


def _cell(reference, value, band=False, header=False):
    style = 1 if header else (3 if band else 2)
    if value is None:
        return f'<c r="{reference}" s="{style}"/>'
    if isinstance(value, bool) and not header:
        return f'<c r="{reference}" s="{style}" t="b"><v>{int(value)}</v></c>'
    if isinstance(value, (datetime, date)) and not header:
        style = (9 if band else 8) if isinstance(value, datetime) else (7 if band else 6)
        return f'<c r="{reference}" s="{style}"><v>{_date_value(value):.15g}</v></c>'
    if isinstance(value, (int, float, Decimal)) and not header:
        # Excel has only 15 significant decimal digits. Preserve long IDs as text.
        if not isinstance(value, int) and not isfinite(value):
            raise ValueError(f"Non-finite number at {reference}")
        if not isinstance(value, int) or abs(value) <= 999999999999999:
            style = 5 if band else 4
            return f'<c r="{reference}" s="{style}"><v>{value}</v></c>'
    content = _text(value)
    if len(content) > 32767:
        raise ValueError(f"Cell text exceeds Excel's 32,767-character limit at {reference}")
    return f'<c r="{reference}" s="{style}" t="inlineStr"><is><t xml:space="preserve">{escape(content)}</t></is></c>'


def _styles():
    xfs = [
        '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>',
        '<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf>',
    ]
    for number_format in (0, 164, 165, 166):
        for fill in (0, 3):
            horizontal = ' horizontal="right"' if number_format == 164 else ""
            xfs.append(f'<xf numFmtId="{number_format}" fontId="0" fillId="{fill}" borderId="0" xfId="0" applyNumberFormat="1" applyAlignment="1"><alignment vertical="top" wrapText="1"{horizontal}/></xf>')
    return _XML_DECL + f'''<styleSheet xmlns="{_NS}">
<numFmts count="3"><numFmt numFmtId="164" formatCode="#,##0.00;[Red](#,##0.00);–"/><numFmt numFmtId="165" formatCode="dd-mmm-yyyy"/><numFmt numFmtId="166" formatCode="dd-mmm-yyyy hh:mm"/></numFmts>
<fonts count="2"><font><sz val="11"/><color rgb="FF243449"/><name val="Calibri"/><family val="2"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/><family val="2"/></font></fonts>
<fills count="4"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF163653"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFF0F5FA"/><bgColor indexed="64"/></patternFill></fill></fills>
<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="10">{''.join(xfs)}</cellXfs>
<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
<dxfs count="0"/><tableStyles count="0" defaultTableStyle="TableStyleMedium2" defaultPivotStyle="PivotStyleLight16"/>
</styleSheet>'''


def _prepare(sheets):
    prepared, used = [], set()
    for index, sheet in enumerate(sheets, 1):
        headers = list(sheet.get("headers", []))
        if not 1 <= len(headers) <= 16384:
            raise ValueError("Every worksheet needs between 1 and 16,384 headers")
        rows = []
        for row in sheet.get("rows", []):
            row = list(row)
            if len(row) > len(headers):
                raise ValueError("A report row has more cells than its headers")
            rows.append(row + [None] * (len(headers) - len(row)))
        if len(rows) > 1048575:
            raise ValueError("A report exceeds Excel's maximum row count")
        name = _BAD_SHEET.sub(" ", _text(sheet.get("name") or f"Sheet {index}")).strip().strip("'")[:31] or f"Sheet {index}"
        base, suffix = name, 2
        while name.casefold() in used:
            ending = f" ({suffix})"
            name = base[:31-len(ending)] + ending
            suffix += 1
        used.add(name.casefold())
        supplied = sheet.get("widths") or []
        widths = []
        for col, header in enumerate(headers):
            if col < len(supplied) and supplied[col] is not None:
                width = float(supplied[col])
                if not isfinite(width) or width < 1:
                    raise ValueError("Column width must be a finite positive number")
                widths.append(min(80, width))
            else:
                values = [header] + [row[col] for row in rows[:100]]
                width = max(len(_text(value)) for value in values if value is not None)
                widths.append(min(48, max(16, width + 2)))
        prepared.append((name, headers, rows, widths))
    if not prepared:
        raise ValueError("At least one worksheet is required")
    return prepared


def _row_height(values, widths, header=False):
    lines = 1
    for value, width in zip(values, widths):
        if value is not None:
            estimate = sum(max(1, ceil(len(line) / max(1, width - 2))) for line in _text(value).split("\n"))
            lines = max(lines, estimate)
    return min(180, max(32 if header else 25, lines * 15 + 8))


def _worksheet(zipfile, filename, sheet):
    _, headers, rows, widths = sheet
    last = f"{_col(len(headers))}{len(rows)+1}"
    with zipfile.open(filename, "w") as target:
        def put(text):
            target.write(text.encode("utf-8"))
        put(_XML_DECL + f'<worksheet xmlns="{_NS}" xmlns:r="{_REL}"><dimension ref="A1:{last}"/><sheetViews><sheetView showGridLines="0" workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/><selection pane="bottomLeft" activeCell="A2" sqref="A2"/></sheetView></sheetViews><sheetFormatPr defaultRowHeight="25"/><cols>')
        for col, width in enumerate(widths, 1):
            put(f'<col min="{col}" max="{col}" width="{width:g}" customWidth="1"/>')
        put('</cols><sheetData>')
        for row_num, row in enumerate([headers] + rows, 1):
            put(f'<row r="{row_num}" ht="{_row_height(row, widths, row_num == 1)}" customHeight="1">')
            for col, value in enumerate(row, 1):
                put(_cell(f"{_col(col)}{row_num}", value, band=row_num % 2 == 1, header=row_num == 1))
            put('</row>')
        put(f'</sheetData><autoFilter ref="A1:{last}"/><printOptions horizontalCentered="0"/><pageMargins left="0.25" right="0.25" top="0.4" bottom="0.4" header="0.2" footer="0.2"/><pageSetup paperSize="9" orientation="landscape" fitToWidth="1" fitToHeight="0"/><headerFooter><oddFooter>&amp;LInvoice Control V2&amp;RPage &amp;P of &amp;N</oddFooter></headerFooter></worksheet>')


def write_xlsx(path, sheets):
    """Atomically write a real .xlsx and return its Path.

    ``sheets`` is a list of {name, headers, rows, widths?}. Rows may contain
    strings, None, bool, int, float, Decimal or date/datetime. Text always stays
    text, including formula-looking strings and account codes with leading 0s.
    Report values are immutable snapshots; no formulas are generated.
    """
    prepared = _prepare(sheets)
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    handle, temp_name = tempfile.mkstemp(prefix=".report-", suffix=".xlsx", dir=path.parent)
    os.close(handle)
    try:
        with ZipFile(temp_name, "w", ZIP_DEFLATED) as archive:
            overrides = ''.join(f'<Override PartName="/xl/worksheets/sheet{i}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' for i in range(1, len(prepared)+1))
            archive.writestr('[Content_Types].xml', _XML_DECL + f'<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>{overrides}</Types>')
            archive.writestr('_rels/.rels', _XML_DECL + f'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="{_REL}/officeDocument" Target="xl/workbook.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/></Relationships>')
            created = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
            archive.writestr('docProps/core.xml', _XML_DECL + f'<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:creator>Invoice Control V2</dc:creator><dcterms:created xsi:type="dcterms:W3CDTF">{created}</dcterms:created></cp:coreProperties>')
            sheet_tags = ''.join(f'<sheet name={quoteattr(name)} sheetId="{i}" r:id="rId{i}"/>' for i, (name, _, _, _) in enumerate(prepared, 1))
            repeats = ''.join(f'<definedName name="_xlnm.Print_Titles" localSheetId="{i}">{escape(chr(39) + name.replace(chr(39), chr(39)*2) + chr(39))}!$1:$1</definedName>' for i, (name, _, _, _) in enumerate(prepared))
            archive.writestr('xl/workbook.xml', _XML_DECL + f'<workbook xmlns="{_NS}" xmlns:r="{_REL}"><bookViews><workbookView activeTab="0"/></bookViews><sheets>{sheet_tags}</sheets><definedNames>{repeats}</definedNames></workbook>')
            relations = ''.join(f'<Relationship Id="rId{i}" Type="{_REL}/worksheet" Target="worksheets/sheet{i}.xml"/>' for i in range(1, len(prepared)+1))
            archive.writestr('xl/_rels/workbook.xml.rels', _XML_DECL + f'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">{relations}<Relationship Id="rId{len(prepared)+1}" Type="{_REL}/styles" Target="styles.xml"/></Relationships>')
            archive.writestr('xl/styles.xml', _styles())
            for i, sheet in enumerate(prepared, 1):
                _worksheet(archive, f'xl/worksheets/sheet{i}.xml', sheet)
        os.replace(temp_name, path)
        return path
    finally:
        if os.path.exists(temp_name):
            os.unlink(temp_name)
