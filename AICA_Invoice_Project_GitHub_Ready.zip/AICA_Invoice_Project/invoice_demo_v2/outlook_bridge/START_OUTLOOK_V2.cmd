@echo off
setlocal DisableDelayedExpansion
powershell.exe -NoLogo -NoProfile -File "%~dp0Outlook_V2.ps1" -V2Root "%~dp0.."
if errorlevel 1 echo Outlook V2 helper stopped with an error. Read the message above.
pause
