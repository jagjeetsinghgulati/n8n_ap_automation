@echo off
setlocal DisableDelayedExpansion
powershell.exe -NoLogo -NoProfile -File "%~dp0Outlook_V2.ps1" -V2Root "%~dp0.." -CheckAccountsOnly
if errorlevel 1 echo Account check failed. Read the message above and share a screenshot of this window.
pause
