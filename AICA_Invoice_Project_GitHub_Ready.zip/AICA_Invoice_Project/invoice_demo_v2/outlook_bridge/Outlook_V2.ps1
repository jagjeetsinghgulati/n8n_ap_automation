# Optional V2 helper. Run interactively as the same Windows user as Classic Outlook.
# It submits only jobs explicitly created with the approval application's Email action.
[CmdletBinding()]
param([string]$V2Root = '', [switch]$CheckAccountsOnly)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
# Resolve paths after parameter binding. The launcher also supplies V2Root explicitly.
# Never infer the queue from the shell's current working directory.
try {
    if ([string]::IsNullOrWhiteSpace($V2Root)) {
        $helperDirectory = $PSScriptRoot
        if ([string]::IsNullOrWhiteSpace($helperDirectory)) {
            $helperScriptPath = $MyInvocation.MyCommand.Path
            if ([string]::IsNullOrWhiteSpace($helperScriptPath)) {
                throw 'Cannot locate the helper script. Run START_OUTLOOK_V2.cmd from your installed outlook_bridge folder.'
            }
            $helperDirectory = Split-Path -Path $helperScriptPath -Parent
        }
        $V2Root = Split-Path -Path $helperDirectory -Parent
    }
    $V2Root = [IO.Path]::GetFullPath($V2Root)
    if (-not (Test-Path -LiteralPath (Join-Path $V2Root 'compose.v2.yaml') -PathType Leaf)) {
        throw 'V2 installation not found. Copy the replacement files into invoice_demo_v2\outlook_bridge, then run START_OUTLOOK_V2.cmd there.'
    }
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}
$queueDir = Join-Path $V2Root 'output\outlook'
[void][IO.Directory]::CreateDirectory($queueDir)
$utf8 = New-Object System.Text.UTF8Encoding($false)
function Get-OutlookSenderAddress($Mail) {
    $mailBase = $Mail.PSObject.BaseObject
    $flags = [Reflection.BindingFlags]::Public -bor [Reflection.BindingFlags]::Instance -bor [Reflection.BindingFlags]::GetProperty
    $selected = $mailBase.GetType().InvokeMember('SendUsingAccount', $flags, $null, $mailBase, $null)
    if ($null -eq $selected) { return '' }
    return ([string]$selected.SmtpAddress).Trim()
}
function Assert-OutlookSender($Mail, [string]$ExpectedSender, [string]$Stage) {
    $actualSender = Get-OutlookSenderAddress $Mail
    if ($actualSender -ine $ExpectedSender) {
        if ([string]::IsNullOrWhiteSpace($actualSender)) { $actualSender = '(none)' }
        throw "Sender verification failed $Stage. Requested: $ExpectedSender; Outlook selected: $actualSender. No send was attempted."
    }
}
function Set-OutlookSender($Mail, $Account, [string]$ExpectedSender) {
    $mailBase = $Mail.PSObject.BaseObject
    $accountBase = $Account.PSObject.BaseObject
    $lastFailure = ''
    # Explicit COM reference assignment avoids the PowerShell property adapter.
    # Both setter variants below target the SAME requested account and are verified.
    foreach ($setter in @([Reflection.BindingFlags]::PutRefDispProperty, [Reflection.BindingFlags]::SetProperty)) {
        try {
            $flags = [Reflection.BindingFlags]::Public -bor [Reflection.BindingFlags]::Instance -bor $setter
            [void]$mailBase.GetType().InvokeMember('SendUsingAccount', $flags, $null, $mailBase, [object[]]@($accountBase))
            Assert-OutlookSender $Mail $ExpectedSender 'after account selection'
            return
        } catch { $lastFailure = $_.Exception.Message }
    }
    throw "Could not select Outlook account $ExpectedSender. $lastFailure No send was attempted."
}
function Write-Receipt([string]$Id,[string]$Status,[string]$Message,[string]$Sender,$To,$Cc) {
    $receipt = [ordered]@{schemaVersion=2;id=$Id;status=$Status;message=$Message;sender=$Sender;to=@($To);cc=@($Cc);timestampUtc=[DateTime]::UtcNow.ToString('o')}
    $target = Join-Path $queueDir ('result_' + $Id + '.json')
    if (Test-Path -LiteralPath $target) { return }
    $temporary = $target + '.tmp'
    [IO.File]::WriteAllText($temporary, ($receipt | ConvertTo-Json -Depth 5), $utf8)
    Move-Item -LiteralPath $temporary -Destination $target
}
function Assert-Address([string]$Address) {
    if ([string]::IsNullOrWhiteSpace($Address) -or $Address -match '[\r\n;,]' -or $Address -notmatch '^[^\s@]+@[^\s@]+\.[^\s@]+$') { throw 'Use complete plain SMTP addresses without display names.' }
    $parsed = New-Object System.Net.Mail.MailAddress($Address)
    if ($parsed.Address -cne $Address) { throw 'Display names are not accepted.' }
}
function Resolve-JobFile([string]$Name,[string]$Extension) {
    if ($Name -notmatch '^[A-Za-z0-9][A-Za-z0-9_.-]*$' -or [IO.Path]::GetFileName($Name) -cne $Name -or [IO.Path]::GetExtension($Name) -ine $Extension) { throw 'Invalid report filename. Only generated basenames of the expected type are accepted.' }
    $path = Join-Path $queueDir $Name
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "Missing report file: $Name" }
    $item = Get-Item -LiteralPath $path
    if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Linked report files are not permitted.' }
    if ($item.Length -le 0 -or $item.Length -gt 25MB) { throw 'Report is empty or exceeds the 25 MB helper limit.' }
    return $path
}
$mutex = New-Object System.Threading.Mutex($false, 'Local\N8nInvoiceOutlookBridgeV2')
$locked = $false
try {
    try { $locked = $mutex.WaitOne(0) } catch [System.Threading.AbandonedMutexException] { $locked = $true }
    if (-not $locked) { throw 'The V2 Outlook helper is already running in this Windows session.' }
    $outlook = New-Object -ComObject Outlook.Application
    $session = $outlook.Session
    Write-Host 'INVOICE V2 - CLASSIC OUTLOOK HELPER - SENDER FIX 2' -ForegroundColor Green
    Write-Host "Watching only: $queueDir"
    Write-Host 'Available exact sender addresses:'
    for ($i=1; $i -le $session.Accounts.Count; $i++) { Write-Host ('  ' + $session.Accounts.Item($i).SmtpAddress) }
    if ($CheckAccountsOnly) {
        Write-Host 'Checking sender selection only. No email will be sent or saved; the queue will not be processed.' -ForegroundColor Cyan
        $failures = 0
        if ($session.Accounts.Count -eq 0) { throw 'No accounts were found in Classic Outlook.' }
        for ($i=1; $i -le $session.Accounts.Count; $i++) {
            $probe = $null
            $testAccount = $session.Accounts.Item($i)
            $testSender = ([string]$testAccount.SmtpAddress).Trim()
            try {
                Assert-Address $testSender
                $probe = $outlook.CreateItem(0)
                Set-OutlookSender $probe $testAccount $testSender
                Write-Host "PASS - sender selected: $testSender" -ForegroundColor Green
            } catch {
                $failures++
                Write-Host ("FAIL - $testSender : " + $_.Exception.Message) -ForegroundColor Red
            } finally {
                if ($null -ne $probe) {
                    try { [void]$probe.Close(1) } catch { Write-Warning 'Could not close the unsaved diagnostic message. Close it without saving if visible.' }
                }
            }
        }
        Write-Host 'Account check finished. This tests sender selection, not delivery.'
        if ($failures -gt 0) { exit 1 }
        return
    }
    Write-Host 'Click Email on an exported report in V2 to request a send.'
    Write-Host 'Fresh jobs submit immediately from the selected account. Keep this helper and Outlook open.'
    Write-Host 'Outlook may request its own security confirmation; normal Outlook policy is respected.'
    Write-Host 'No automatic retries. Ctrl+C stops this helper. V1 uses a separate helper.'
    foreach ($old in @(Get-ChildItem -LiteralPath $queueDir -Filter 'job_*.processing' -File)) {
        if ($old.Name -match '^job_([A-Za-z0-9_-]+)\.processing$') {
            try { Write-Receipt $Matches[1] 'unknown' 'A previous helper stopped after claiming this job. It will not be retried. Check Outlook Sent Items, Outbox and Drafts before requesting another send.' '' @() @() } catch { Write-Warning 'Could not record an unfinished job; inspect Outlook before retrying.' }
        }
    }
    while ($true) {
        foreach ($file in @(Get-ChildItem -LiteralPath $queueDir -Filter 'job_*.json' -File | Sort-Object Name)) {
            if ($file.Name -notmatch '^job_([A-Za-z0-9_-]+)\.json$') { continue }
            $id = $Matches[1]
            try { $job = [IO.File]::ReadAllText($file.FullName) | ConvertFrom-Json } catch { continue }
            $claimed = [IO.Path]::ChangeExtension($file.FullName, '.processing')
            $receiptPath = Join-Path $queueDir ('result_' + $id + '.json')
            if ((Test-Path -LiteralPath $claimed) -or (Test-Path -LiteralPath $receiptPath)) { continue }
            try { Move-Item -LiteralPath $file.FullName -Destination $claimed } catch { continue }
            $sender = ''; $toList = @(); $ccList = @(); $sendAttempted = $false
            try {
                foreach ($key in @('schemaVersion','id','sender','to','cc','subject','body_file','attachments','expiresAtUtc')) {
                    if ($null -eq $job.PSObject.Properties[$key]) { throw "Required job field missing: $key" }
                }
                if ($job.schemaVersion -ne 2 -or [string]$job.id -cne $id) { throw 'Invalid V2 job schema or job identity.' }
                $expiry = [DateTimeOffset]::Parse([string]$job.expiresAtUtc, [Globalization.CultureInfo]::InvariantCulture)
                if ([DateTimeOffset]::UtcNow -gt $expiry) { throw 'The email request expired. No send was attempted. Make a fresh request from the approval screen if still required.' }
                if ($expiry -gt [DateTimeOffset]::UtcNow.AddMinutes(10)) { throw 'Invalid email request expiry.' }
                $sender = [string]$job.sender
                Assert-Address $sender
                $toList = @($job.to); $ccList = @($job.cc)
                if ($toList.Count -lt 1 -or ($toList.Count + $ccList.Count) -gt 50) { throw 'Provide 1 to 50 recipient addresses.' }
                foreach ($address in @($toList + $ccList)) { Assert-Address ([string]$address) }
                if ([string]::IsNullOrWhiteSpace([string]$job.subject) -or [string]$job.subject -match '[\r\n]' -or ([string]$job.subject).Length -gt 250) { throw 'Invalid subject.' }
                $body = Resolve-JobFile ([string]$job.body_file) '.html'
                $names = @($job.attachments)
                if ($names.Count -lt 1 -or $names.Count -gt 3) { throw 'One to three exported Excel attachments are required.' }
                $attachments = @($names | ForEach-Object { Resolve-JobFile ([string]$_) '.xlsx' })
                $account = $null
                for ($i=1; $i -le $session.Accounts.Count; $i++) {
                    $candidate = $session.Accounts.Item($i)
                    if ([string]$candidate.SmtpAddress -ieq $sender) { $account = $candidate; break }
                }
                if ($null -eq $account) { throw 'The exact selected sender account is not configured in Classic Outlook. No fallback account is used.' }
                if ($session.Offline) { throw 'Outlook is offline. No send was attempted.' }
                # Recheck expiry immediately before creating a mail item.
                if ([DateTimeOffset]::UtcNow -gt $expiry) { throw 'Email request expired during checks. No send was attempted.' }
                $mail = $outlook.CreateItem(0)
                Set-OutlookSender $mail $account $sender
                foreach ($address in $toList) { $recipient = $mail.Recipients.Add([string]$address); $recipient.Type = 1 }
                foreach ($address in $ccList) { $recipient = $mail.Recipients.Add([string]$address); $recipient.Type = 2 }
                if (-not $mail.Recipients.ResolveAll()) { throw 'Outlook could not resolve every recipient.' }
                $mail.Subject = [string]$job.subject
                $mail.BodyFormat = 2
                $mail.HTMLBody = [IO.File]::ReadAllText($body, [Text.Encoding]::UTF8)
                foreach ($path in $attachments) { [void]$mail.Attachments.Add($path) }
                $mail.Save()
                Assert-OutlookSender $mail $sender 'after saving the draft'
                if ([DateTimeOffset]::UtcNow -gt $expiry) { throw 'Email request expired before submission. No send was attempted. An unsent draft may exist in Outlook.' }
                Write-Host "Submitting V2 job $id from $sender" -ForegroundColor Cyan
                $sendAttempted = $true
                $mail.Send()
                Write-Receipt $id 'submitted' 'Outlook Send() returned. Check Sent Items/Outbox. This confirms submission to Outlook, not delivery to recipients.' $sender $toList $ccList
                Move-Item -LiteralPath $claimed -Destination ([IO.Path]::ChangeExtension($claimed, '.done'))
                Write-Host "SUBMITTED: $id" -ForegroundColor Green
            } catch {
                $message = $_.Exception.Message
                $status = 'error'
                if ($sendAttempted) { $status = 'unknown'; $message += ' A send was attempted. Check Sent Items/Outbox/Drafts before repeating. No automatic retry.' }
                Write-Warning ($id + ': ' + $message)
                try {
                    Write-Receipt $id $status $message $sender $toList $ccList
                    Move-Item -LiteralPath $claimed -Destination ([IO.Path]::ChangeExtension($claimed, '.failed'))
                } catch { Write-Warning 'Could not save the final email status. The claimed job will not be retried. Check Outlook before another send.' }
            }
        }
        Start-Sleep -Seconds 2
    }
} catch { Write-Host $_.Exception.Message -ForegroundColor Red; exit 1 }
finally { if ($locked) { $mutex.ReleaseMutex() }; $mutex.Dispose() }
