@echo off
setlocal
powershell.exe -NoLogo -NoProfile -File "%~dp0scripts\Setup.ps1"
if errorlevel 1 echo Operation did not complete. Read the error above.
pause
