"""Financial controls and data boundary tests; run with unittest discovery."""
import copy
import math
from pathlib import Path
import sys
import unittest
from decimal import Decimal

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))
from domain import checks, invoice_identity, money, sanitize_data, suggest_entries, suggest_voucher


def good_invoice():
    return {
        "invoice_number": "AB/2026/001", "supplier_name": "Aster Supplies",
        "supplier_gstin": "06ABCDE1234F1Z5", "buyer_name": "Meridian",
        "invoice_date": "2026-09-01", "due_date": "2026-10-01", "currency": "INR",
        "document_type": "INVOICE", "description": "Paper purchase", "notes": "",
        "category": "Office supplies", "category_reason": "Office stationery",
        "taxable_value": 1000, "cgst": 90, "sgst": 90, "igst": 0,
        "other_charges": 0, "round_off": 0, "invoice_total": 1180,
        "line_items": [{"description": "A4 paper", "quantity": 10, "unit_price": 100,
                        "taxable_amount": 1000}],
        "source_file": "invoice.pdf", "raw_text": "Aster Supplies paper invoice", "flags": [],
    }


SETTINGS = {"companyName": "Meridian", "highValueThreshold": 100000,
            "asOfDate": "2026-10-08", "toleranceINR": 0.01}


def findings(data, entries=None, voucher=None, candidates=None, settings=None):
    return checks(data, suggest_entries(data) if entries is None else entries,
                  suggest_voucher(data, "Meridian") if voucher is None else voucher,
                  settings or SETTINGS, candidates)


def codes(result, severity=None):
    return {item["code"] for item in result if severity is None or item["severity"] == severity}


class DomainTests(unittest.TestCase):
    def test_balanced_happy_case_and_no_unpaid_finding(self):
        data = sanitize_data(good_invoice())
        self.assertEqual([], findings(data))
        self.assertEqual(money(1180), sum((money(e["debit"]) for e in suggest_entries(data)), Decimal(0)))

    def test_null_is_not_zero(self):
        data = good_invoice()
        data["igst"] = None
        normalized = sanitize_data(data)
        self.assertIsNone(normalized["igst"])
        self.assertEqual([], suggest_entries(normalized))
        self.assertIn("MISSING_AMOUNTS", codes(findings(normalized), "block"))

    def test_numeric_boundary_rejects_bool_nan_infinity_and_objects(self):
        for value in (True, False, float("nan"), float("inf"), -float("inf"), "NaN", "Infinity", {}, [], "INR 100", "1,000"):
            with self.subTest(value=value):
                data = good_invoice()
                data["invoice_total"] = value
                with self.assertRaises(ValueError):
                    sanitize_data(data)
        with self.assertRaises(ValueError):
            money(None)

    def test_blank_value_stays_unknown_and_decimal_strings_supported(self):
        data = good_invoice()
        data["igst"] = "  "
        data["taxable_value"] = "1000.005"
        normalized = sanitize_data(data)
        self.assertIsNone(normalized["igst"])
        self.assertEqual(1000.01, normalized["taxable_value"])
        self.assertEqual(Decimal("-0.01"), money("-0.005"))

    def test_quantity_and_rate_precision_preserved(self):
        data = good_invoice()
        data["line_items"][0].update(quantity=1.23456, unit_price=100.123456)
        normalized = sanitize_data(data)
        self.assertEqual(1.23456, normalized["line_items"][0]["quantity"])
        self.assertEqual(100.123456, normalized["line_items"][0]["unit_price"])

    def test_line_product_out_of_range_is_a_block_not_a_crash(self):
        data = good_invoice()
        data["line_items"][0].update(quantity=999999999999, unit_price=999999999999)
        self.assertIn("LINE_NUMBER_RANGE", codes(findings(data), "block"))

    def test_source_and_flags_preserved_status_not_trusted(self):
        data = good_invoice()
        data.update(status="APPROVED", flags=["SOURCE_MISMATCH", "SOURCE_MISMATCH"])
        normalized = sanitize_data(data)
        self.assertEqual(data["source_file"], normalized["source_file"])
        self.assertEqual(data["raw_text"], normalized["raw_text"])
        self.assertEqual(["SOURCE_MISMATCH"], normalized["flags"])
        self.assertNotIn("status", normalized)

    def test_total_mismatch_blocks_even_with_balanced_manual_journal(self):
        data = good_invoice()
        data["invoice_total"] = 1200
        entries = suggest_entries(good_invoice())
        entries[0]["debit"] += 20
        entries[-1]["credit"] = 1200
        self.assertIn("TOTAL_MISMATCH", codes(findings(data, entries), "block"))
        self.assertNotIn("UNBALANCED_ENTRY", codes(findings(data, entries)))

    def test_source_tolerance_cannot_relax_entry_tolerance(self):
        data = good_invoice()
        data["invoice_total"] = 1180.50
        settings = {**SETTINGS, "toleranceINR": 1}
        result = findings(data, settings=settings)
        self.assertNotIn("TOTAL_MISMATCH", codes(result))
        self.assertIn("UNBALANCED_ENTRY", codes(result, "block"))

    def test_missing_lines_review_line_total_hard_and_discount_review(self):
        data = good_invoice()
        data["line_items"] = []
        self.assertIn("MISSING_LINES", codes(findings(data), "review"))
        data = good_invoice()
        data["line_items"][0]["taxable_amount"] = 999
        self.assertIn("LINE_TOTAL_MISMATCH", codes(findings(data), "block"))
        data = good_invoice()
        data["line_items"][0]["unit_price"] = 105
        self.assertIn("LINE_CALCULATION", codes(findings(data), "review"))

    def test_negative_credit_documents_unsupported_but_negative_rounding_allowed(self):
        data = good_invoice()
        data["document_type"] = "CREDIT_NOTE"
        self.assertIn("DOCUMENT_REVIEW", codes(findings(data), "block"))
        self.assertEqual([], suggest_entries(data))
        data = good_invoice()
        data["taxable_value"] = -1000
        self.assertIn("NEGATIVE_AMOUNT", codes(findings(data), "block"))
        data = good_invoice()
        data["round_off"] = -.25
        data["invoice_total"] -= .25
        self.assertEqual([], findings(data))

    def test_identity_financial_year_boundaries_and_punctuation(self):
        data = good_invoice()
        data["invoice_date"] = "2026-03-31"
        self.assertEqual(("MERIDIAN", "06ABCDE1234F1Z5", "2025-26", "AB2026001"), invoice_identity(data, "Meridian"))
        data["invoice_date"] = "2026-04-01"
        self.assertEqual("2026-27", invoice_identity(data, "Meridian")[2])
        data["invoice_date"] = "2026-02-30"
        data["supplier_gstin"] = None
        self.assertEqual(("MERIDIAN", "ASTERSUPPLIES", "", "AB2026001"), invoice_identity(data, "Meridian"))

    def test_duplicate_hard(self):
        self.assertIn("POTENTIAL_DUPLICATE", codes(findings(good_invoice(), candidates=[{"id": "INV-1"}]), "block"))

    def test_source_failures_hard_source_mismatch_review(self):
        data = good_invoice()
        data["flags"] = ["NO_READABLE_TEXT", "LLM_EXTRACTION_ERROR", "SOURCE_MISMATCH", "INVALID_NUMBER_CGST"]
        result = findings(data)
        self.assertTrue({"NO_READABLE_TEXT", "LLM_EXTRACTION_ERROR", "INVALID_NUMBER_CGST"}.issubset(codes(result, "block")))
        self.assertIn("SOURCE_MISMATCH", codes(result, "review"))

    def test_derived_old_flags_recomputed_after_correction(self):
        data = good_invoice()
        data["flags"] = ["TOTAL_MISMATCH", "MISSING_DATE"]
        self.assertEqual([], findings(data))

    def test_ledger_empty_entries_and_invalid_sides_block(self):
        data = good_invoice()
        for mutate, expected in (
            (lambda e: e[0].update(ledger=""), "MISSING_LEDGER"),
            (lambda e: e[0].update(debit=-1), "INVALID_ENTRY_SIDE"),
            (lambda e: e[0].update(credit=10), "INVALID_ENTRY_SIDE"),
            (lambda e: e[0].update(debit=0), "INVALID_ENTRY_SIDE"),
            (lambda e: e[0].update(debit=None), "INVALID_ENTRY_AMOUNT"),
        ):
            entries = suggest_entries(data)
            mutate(entries)
            with self.subTest(expected=expected):
                self.assertIn(expected, codes(findings(data, entries), "block"))
        self.assertIn("MISSING_ENTRIES", codes(findings(data, []), "block"))

    def test_balanced_but_wrong_gross_rejected(self):
        data = good_invoice()
        entries = [{"ledger": "Purchase", "debit": 100, "credit": 0},
                   {"ledger": "Aster Supplies", "debit": 0, "credit": 100}]
        result = findings(data, entries)
        self.assertNotIn("UNBALANCED_ENTRY", codes(result))
        self.assertIn("ENTRY_TOTAL_MISMATCH", codes(result, "block"))
        self.assertIn("SUPPLIER_PAYABLE_MISMATCH", codes(result, "block"))

    def test_company_date_currency_document_required(self):
        data = good_invoice()
        data["currency"] = None
        data["invoice_date"] = "2026-02-30"
        result = findings(data, voucher={"company": "", "voucher_type": "", "voucher_date": ""})
        self.assertTrue({"CURRENCY_REVIEW", "MISSING_DATE", "VOUCHER_COMPANY", "VOUCHER_TYPE", "VOUCHER_DATE"}.issubset(codes(result, "block")))
        result = findings(good_invoice(), voucher={"company": "Different Ltd", "voucher_type": "Purchase", "voucher_date": "2026-09-01"})
        self.assertIn("COMPANY_MISMATCH", codes(result, "block"))

    def test_gstin_not_tax_registry_and_categories_only_review(self):
        data = good_invoice()
        data.update(supplier_gstin="bad", category="IT equipment", invoice_total=118000,
                    taxable_value=100000, cgst=9000, sgst=9000)
        data["line_items"] = []
        result = findings(data)
        self.assertTrue({"GSTIN_FORMAT", "CAPEX_REVIEW", "HIGH_VALUE"}.issubset(codes(result, "review")))
        self.assertEqual(set(), codes(result, "block"))


if __name__ == "__main__":
    unittest.main()
