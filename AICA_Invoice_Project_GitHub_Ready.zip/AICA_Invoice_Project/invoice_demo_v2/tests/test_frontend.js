'use strict';
// Execute the actual registered login handler with a deferred HTTP response.
// Browsers clear Event.currentTarget once dispatch returns; preserve that
// behaviour here so a post-await access fails this regression test.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { test } = require('node:test');

const app = fs.readFileSync(path.join(__dirname, '../app/static/app.js'), 'utf8');
const registration = app.split('\n').find(line => line.startsWith("$('login-form').addEventListener('submit',"));
assert.ok(registration, 'Locate the actual login submit handler');

function setup() {
  let handler, resolveRequest, rejectRequest, prevented = false, refreshCount = 0;
  const errors = [], calls = [], submitButton = { disabled: false };
  const form = {
    elements: { username: { value: 'reviewer' }, password: { value: 'test-password' } },
    querySelector(selector) { assert.equal(selector, 'button'); return submitButton; },
    addEventListener(event, callback) { assert.equal(event, 'submit'); handler = callback; },
  };
  const context = {
    $(id) { assert.equal(id, 'login-form'); return form; },
    csrf: '',
    FormData: class {
      constructor(target) { assert.equal(target, form); this.values = Object.fromEntries(Object.entries(target.elements).map(([key, field]) => [key, field.value])); }
      get(key) { return this.values[key]; }
    },
    errorAt(id, message) { assert.equal(id, 'login-error'); errors.push(message); },
    api(...args) { calls.push(args); return new Promise((resolve, reject) => { resolveRequest = resolve; rejectRequest = reject; }); },
    async refresh() { refreshCount += 1; },
  };
  vm.runInNewContext(registration, context, { filename: 'login-handler-under-test.js' });
  const event = { currentTarget: form, preventDefault() { prevented = true; } };
  const completion = handler(event);
  // The first await returns control to the browser event dispatcher.
  event.currentTarget = null;
  return { form, context, completion, calls, errors, submitButton,
    resolve(value) { resolveRequest(value); }, reject(error) { rejectRequest(error); },
    get prevented() { return prevented; }, get refreshCount() { return refreshCount; } };
}

test('successful asynchronous login survives currentTarget becoming null', async () => {
  const h = setup();
  assert.equal(h.prevented, true);
  assert.equal(h.submitButton.disabled, true);
  assert.equal(h.calls[0][0], '/api/login');
  assert.equal(h.calls[0][1], 'POST');
  assert.equal(h.calls[0][2].username, 'reviewer');
  assert.equal(h.calls[0][2].password, 'test-password');
  h.resolve({ user: 'reviewer', csrf: 'fresh-csrf' });
  await h.completion;
  assert.equal(h.form.elements.password.value, '');
  assert.equal(h.context.csrf, 'fresh-csrf');
  assert.equal(h.refreshCount, 1);
  assert.equal(h.submitButton.disabled, false);
  assert.deepEqual(h.errors, ['']);
});

test('failed asynchronous login shows the server error and permits retry', async () => {
  const h = setup();
  h.reject(new Error('Incorrect username or password.'));
  await h.completion;
  assert.equal(h.form.elements.password.value, 'test-password');
  assert.equal(h.refreshCount, 0);
  assert.equal(h.submitButton.disabled, false);
  assert.deepEqual(h.errors, ['', 'Incorrect username or password.']);
});
