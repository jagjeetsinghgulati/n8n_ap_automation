"""Offline integration tests: lifecycle, SQLite persistence, exports and restore.

Each test creates an isolated database and file tree. No model, email account,
Outlook instance or Tally company is contacted. Fixture facts are injected at the
same API boundary where n8n would submit extraction results.
"""
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sqlite3
import sys
import tempfile
import unittest
from unittest.mock import patch
import xml.etree.ElementTree as ET
import zipfile

PACKAGE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PACKAGE / "app"))
from domain import sanitize_data, suggest_entries, suggest_voucher

FIXTURES = json.loads((PACKAGE / "tests/invoice_expected.json").read_text())
COMPANY = "Northstar Precision Components Pvt Ltd"


def workbook_rows(path):
    """Read our inline-string XLSX output with stdlib only, for report assertions."""
    ns = {"s": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
    result = {}
    with zipfile.ZipFile(path) as archive:
        workbook = ET.fromstring(archive.read("xl/workbook.xml"))
        for index, sheet in enumerate(workbook.find("s:sheets", ns), 1):
            xml = ET.fromstring(archive.read(f"xl/worksheets/sheet{index}.xml"))
            table = []
            for row in xml.findall("s:sheetData/s:row", ns):
                cells = []
                for cell in row.findall("s:c", ns):
                    text = cell.find("s:is/s:t", ns)
                    number = cell.find("s:v", ns)
                    cells.append(text.text if text is not None else float(number.text) if number is not None else None)
                table.append(cells)
            result[sheet.get("name")] = table
    return result


class IntegrationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="invoice-v2-test-")
        root = Path(self.temp.name)
        with patch.dict(os.environ, {"ROOT_DIR": str(root / "files"),
                                     "DATA_DIR": str(root / "db"),
                                     "INVOICE_API_TOKEN": "test-token-no-network-123456789",
                                     "INVOICE_PASSWORD": "test-password-no-network"}):
            spec = importlib.util.spec_from_file_location("invoice_server_test", PACKAGE / "app/server.py")
            self.s = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(self.s)
        self.s.init_db()
        self.run_counter = 0
        settings = {**self.s.get_settings(), "asOfDate": "2026-10-08", "companyName": COMPANY}
        with self.s.DB:
            self.s.DB.execute("UPDATE settings SET value=? WHERE key='settings'", (self.s.jd(settings),))

    def tearDown(self):
        try:
            self.s.DB.close()
        except (AttributeError, sqlite3.Error):
            pass
        self.temp.cleanup()

    def call(self, fn, *args, **kwargs):
        with self.s.DB:
            return fn(*args, **kwargs)

    def add_pdf(self, index=0, filename=None, changed=False):
        fixture = FIXTURES[index]
        name = filename or fixture["source_file"]
        source = PACKAGE / "sample_invoices" / fixture["source_file"]
        raw = source.read_bytes()
        if changed:
            raw += b"\n% correction version\n"
        (self.s.ROOT / "input" / name).write_bytes(raw)
        return name

    def clear_input(self):
        for file in (self.s.ROOT / "input").iterdir():
            file.unlink()

    def start(self, run=None):
        self.run_counter += 1
        return self.call(self.s.start_batch, {"runKey": run or f"test-{self.run_counter}",
                  "companyName": COMPANY, "asOfDate": "2026-10-08", "model": "qwen2.5:7b"})

    def result(self, batch, job, data):
        return self.call(self.s.ingest_result, {"batch_id": batch["batch_id"],
                         "invoice_id": job["invoice_id"], "version_id": job["version_id"],
                         "data": copy.deepcopy(data)})

    def finish(self, batch, **kwargs):
        return self.call(self.s.finish_batch, batch["batch_id"], **kwargs)

    def one(self, index=0, data=None, changed=False, filename=None):
        self.clear_input()
        self.add_pdf(index, changed=changed, filename=filename)
        batch = self.start()
        self.assertEqual(1, len(batch["files"]))
        job = batch["files"][0]
        self.result(batch, job, FIXTURES[index] if data is None else data)
        self.finish(batch)
        return job["invoice_id"]

    def action(self, invoice_id, action, **kwargs):
        payload = {"version": self.s.get_invoice(invoice_id)["current_version"],
                   "action": action, "reason": "Reviewed against original document", **kwargs}
        return self.call(self.s.action_invoice, invoice_id, payload, "Reviewer One")

    def approve(self, invoice_id):
        d = self.s.detail(invoice_id)
        return self.action(invoice_id, "approve", ledger_confirmed=True,
             exception_codes=[x["code"] for x in d["checks"] if x["severity"] == "review"])

    def edit(self, invoice_id, data=None, **overrides):
        d = self.s.detail(invoice_id)
        selected = copy.deepcopy(d["data"] if data is None else data)
        payload = {"version": d["invoice"]["current_version"],
                   "data": selected, "entries": suggest_entries(selected),
                   "voucher": suggest_voucher(selected, COMPANY),
                   "reason": "Corrected after checking the original PDF", **overrides}
        return self.call(self.s.edit_invoice, invoice_id, payload, "Reviewer One")

    def test_registers_before_extraction_and_reports_all_file_receipts(self):
        self.add_pdf(0)
        self.add_pdf(1)
        (self.s.ROOT / "input/broken.pdf").write_bytes(b"not a pdf")
        batch = self.start("same-execution")
        self.assertEqual(3, batch["received"])
        self.assertEqual(2, len(batch["files"]))
        self.assertEqual(3, len(self.s.rows("SELECT * FROM receipts")))
        for job in batch["files"]:
            inv = self.s.get_invoice(job["invoice_id"])
            self.assertEqual("processing", inv["status"])
            v = self.s.get_version(inv["id"])
            doc = self.s.row("SELECT * FROM documents WHERE id=?", (v["document_id"],))
            self.assertTrue((self.s.ROOT / "archive" / doc["archive_name"]).is_file())
        repeated = self.start("same-execution")
        self.assertEqual(batch["batch_id"], repeated["batch_id"])
        self.assertEqual(2, len(repeated["files"]))
        with self.assertRaises(self.s.Problem) as caught:
            self.start("overlap")
        self.assertEqual(409, caught.exception.status)
        self.result(batch, batch["files"][0], FIXTURES[0])
        self.result(batch, batch["files"][1], FIXTURES[1])
        finished = self.finish(batch)
        self.assertEqual("partly_completed", finished["status"])
        self.assertEqual(2, finished["summary"]["extracted"])
        self.assertEqual(1, finished["summary"]["errors"])
        for report in finished["reports"]:
            with zipfile.ZipFile(self.s.ROOT / "output" / report["filename"]) as z:
                self.assertIsNone(z.testzip())

    def test_all_twenty_fixture_invoices_and_seeded_exceptions(self):
        self.assertEqual(20, len(FIXTURES))
        for index in range(20):
            self.add_pdf(index)
        batch = self.start()
        by_name = {x["source_file"]: x for x in FIXTURES}
        for job in batch["files"]:
            self.result(batch, job, by_name[job["source_file"]])
        finished = self.finish(batch)
        self.assertEqual(20, finished["summary"]["extracted"])
        self.assertEqual(20, len(self.s.rows("SELECT * FROM invoices")))
        for job in batch["files"]:
            d = self.s.detail(job["invoice_id"])
            code = {x["code"] for x in d["checks"]}
            if job["source_file"].startswith("15_"):
                self.assertIn("TOTAL_MISMATCH", code)
                with self.assertRaises(self.s.Problem): self.approve(job["invoice_id"])
            elif job["source_file"].startswith("19_"):
                self.assertIn("MISSING_DUE_DATE", code)
            elif job["source_file"].startswith("18_"):
                self.assertIn("DEPOSIT_REVIEW", code)
            elif job["source_file"].startswith("07_"):
                self.assertIn("CAPEX_REVIEW", code)

    def test_identical_file_is_skipped_in_same_and_next_batch(self):
        self.add_pdf(0)
        self.add_pdf(0, filename="copy.pdf")
        batch = self.start()
        self.assertEqual(2, batch["received"])
        self.assertEqual(1, batch["duplicate_count"])
        self.assertEqual(1, len(batch["files"]))
        self.result(batch, batch["files"][0], FIXTURES[0])
        self.finish(batch)
        repeated = self.start()
        self.assertEqual(2, repeated["duplicate_count"])
        self.assertEqual([], repeated["files"])
        self.finish(repeated)
        self.assertEqual(1, len(self.s.rows("SELECT * FROM invoices")))

    def test_failure_retry_keeps_invoice_id_and_preserves_failed_revision(self):
        failure = {"flags": ["NO_READABLE_TEXT"], "raw_text": ""}
        invoice_id = self.one(data=failure)
        self.assertEqual("processing_problem", self.s.get_invoice(invoice_id)["status"])
        batch = self.start()
        job = batch["files"][0]
        self.assertEqual(invoice_id, job["invoice_id"])
        self.assertEqual(2, job["version_id"])
        self.result(batch, job, FIXTURES[0])
        self.finish(batch)
        self.assertEqual("awaiting_approval", self.s.get_invoice(invoice_id)["status"])
        self.assertIn("NO_READABLE_TEXT", self.s.get_version(invoice_id, 1)["data"]["flags"])
        self.assertEqual("qwen_extraction", self.s.get_version(invoice_id, 2)["source"])

    def test_result_idempotency_cannot_overwrite_reviewed_current_data(self):
        self.add_pdf(0)
        batch = self.start()
        job = batch["files"][0]
        self.result(batch, job, FIXTURES[0])
        self.finish(batch)
        corrected = copy.deepcopy(FIXTURES[0])
        corrected["notes"] = "Reviewed contract reference PO-900"
        self.edit(job["invoice_id"], corrected)
        original = self.result(batch, job, {"flags": ["LLM_EXTRACTION_ERROR"]})
        self.assertTrue(original["idempotent"])
        self.assertEqual(corrected["notes"], self.s.get_version(job["invoice_id"])["data"]["notes"])
        self.assertEqual(2, self.s.get_invoice(job["invoice_id"])["current_version"])
        original_payload = self.s.version_history(job["invoice_id"], 1)["original_extraction"]
        self.assertEqual(FIXTURES[0], original_payload["payload"])
        self.assertTrue(original_payload["received_at"])

    def test_invalid_extraction_original_payload_is_retained_for_review(self):
        invalid = copy.deepcopy(FIXTURES[0])
        invalid["invoice_total"] = {"model_returned": "not numeric"}
        invalid["unexpected_model_field"] = "keep as evidence even though outside schema"
        invoice_id = self.one(data=invalid)
        self.assertEqual("processing_problem", self.s.get_invoice(invoice_id)["status"])
        original = self.s.version_history(invoice_id, 1)["original_extraction"]["payload"]
        self.assertEqual(invalid, original)
        self.edit(invoice_id, FIXTURES[0])
        self.assertEqual(invalid, self.s.version_history(invoice_id, 1)["original_extraction"]["payload"])

    def test_company_cannot_change_after_workspace_contains_invoice_records(self):
        invoice_id = self.one()
        before = self.s.get_settings()
        with self.assertRaises(self.s.Problem):
            self.call(self.s.start_batch, {"runKey": "accidental-company-switch",
                      "companyName": "Unrelated Company Pvt Ltd", "asOfDate": "2026-10-08"})
        self.assertEqual(before, self.s.get_settings())
        self.assertFalse(self.s.row("SELECT * FROM batches WHERE run_key=?", ("accidental-company-switch",)))
        self.assertNotIn("COMPANY_MISMATCH", {x["code"] for x in self.s.detail(invoice_id)["checks"]})

    def test_approval_requires_ledger_confirmation_and_explicit_soft_acceptance(self):
        invoice_id = self.one(18)
        with self.assertRaises(self.s.Problem):
            self.action(invoice_id, "approve", exception_codes=["MISSING_DUE_DATE"])
        with self.assertRaises(self.s.Problem):
            self.action(invoice_id, "approve", ledger_confirmed=True, exception_codes=[])
        with self.assertRaises(self.s.Problem):
            self.action(invoice_id, "approve", ledger_confirmed=True,
                        exception_codes=["MISSING_DUE_DATE"], reason="")
        self.approve(invoice_id)
        inv = self.s.get_invoice(invoice_id)
        approval = json.loads(inv["approval_json"])
        self.assertEqual("approved_awaiting_entry", inv["status"])
        self.assertEqual("Reviewer One", approval["actor"])
        self.assertIn("MISSING_DUE_DATE", approval["accepted"])
        self.assertEqual(inv["current_version"], approval["version"])

    def test_hard_math_and_source_failures_cannot_be_waived(self):
        invoice_id = self.one(14)
        d = self.s.detail(invoice_id)
        with self.assertRaises(self.s.Problem):
            self.action(invoice_id, "approve", ledger_confirmed=True,
                        exception_codes=[x["code"] for x in d["checks"]])
        self.assertEqual("awaiting_approval", self.s.get_invoice(invoice_id)["status"])
        self.assertIsNone(self.s.get_invoice(invoice_id)["approval_json"])

    def test_edit_increments_revision_resets_approval_and_rejects_stale_actions(self):
        invoice_id = self.one()
        self.approve(invoice_id)
        before = self.s.get_version(invoice_id)
        data = copy.deepcopy(before["data"])
        data["notes"] = "Revised narration following invoice review"
        after = self.edit(invoice_id, data)
        self.assertEqual(2, after["invoice"]["current_version"])
        self.assertEqual("awaiting_approval", after["invoice"]["status"])
        self.assertIsNone(self.s.get_invoice(invoice_id)["approval_json"])
        self.assertEqual(before["data"], self.s.get_version(invoice_id, 1)["data"])
        with self.assertRaises(self.s.Problem) as caught:
            self.action(invoice_id, "hold", version=1)
        self.assertEqual(409, caught.exception.status)
        with self.assertRaises(self.s.Problem):
            self.edit(invoice_id, version=1)

    def test_hold_return_reject_reopen_are_audited_and_persist_after_restart(self):
        invoice_id = self.one()
        for action, status in (("hold", "on_hold"), ("return", "returned_for_correction"),
                               ("reject", "rejected_closed"), ("reopen", "awaiting_approval")):
            self.action(invoice_id, action)
            self.assertEqual(status, self.s.get_invoice(invoice_id)["status"])
        self.s.DB.close()
        self.s.init_db()
        actions = {h["action"] for h in self.s.detail(invoice_id)["history"]}
        self.assertTrue({"hold", "return", "reject", "reopen"}.issubset(actions))
        self.assertEqual("awaiting_approval", self.s.get_invoice(invoice_id)["status"])

    def test_outstanding_workbook_captures_hold_reason_age_amount_and_lines(self):
        invoice_id = self.one()
        self.action(invoice_id, "hold", reason="Awaiting signed delivery challan from warehouse")
        report = self.call(self.s.make_export, {"kind": "outstanding"}, "Reviewer One")
        sheets = workbook_rows(self.s.ROOT / "output" / report["filename"])
        register = [dict(zip(sheets["Outstanding"][0], row)) for row in sheets["Outstanding"][1:]]
        self.assertEqual(1, len(register))
        line = register[0]
        self.assertEqual(invoice_id, line["Invoice ID"])
        self.assertEqual("on_hold", line["Status"])
        self.assertEqual("hold", line["Latest decision"])
        self.assertEqual("Awaiting signed delivery challan from warehouse", line["Latest decision reason"])
        self.assertEqual("Reviewer One", line["Decision by"])
        self.assertTrue(line["Decision at UTC"])
        self.assertGreaterEqual(line["Days since receipt"], 0)
        self.assertEqual(FIXTURES[0]["invoice_total"], line["Invoice total"])
        totals = dict(zip(sheets["Status Totals"][0], sheets["Status Totals"][1]))
        self.assertEqual("on_hold", totals["Status"])
        self.assertEqual("INR", totals["Currency"])
        self.assertEqual(1, totals["Invoice count"])
        self.assertEqual(FIXTURES[0]["invoice_total"], totals["Known invoice total"])
        self.assertEqual(len(FIXTURES[0]["line_items"]), len(sheets["Invoice Line Items"])-1)

    def test_export_reservation_releases_and_preserves_stale_snapshot(self):
        invoice_id = self.one()
        self.approve(invoice_id)
        export = self.call(self.s.make_export, {"kind": "approved"}, "Reviewer One")
        file = self.s.ROOT / "output" / export["filename"]
        original_bytes = file.read_bytes()
        self.assertEqual(export["id"], self.s.get_invoice(invoice_id)["export_id"])
        with self.assertRaises(self.s.Problem):
            self.call(self.s.make_export, {"kind": "approved"}, "Reviewer One")
        self.call(self.s.release_export, export["id"], {"reason": "Discarded earlier workbook before use"}, "Reviewer One")
        self.assertIsNone(self.s.get_invoice(invoice_id)["export_id"])
        second = self.call(self.s.make_export, {"kind": "approved"}, "Reviewer One")
        data = copy.deepcopy(self.s.get_version(invoice_id)["data"])
        data["notes"] = "Correction requires a fresh approval"
        self.edit(invoice_id, data)
        self.assertEqual("contains_superseded", self.s.row("SELECT * FROM exports WHERE id=?", (second["id"],))["status"])
        self.assertEqual(original_bytes, file.read_bytes())
        with self.assertRaises(self.s.Problem):
            self.call(self.s.queue_email, second["id"], {"sender": "s@example.com", "to": "r@example.com"}, "Reviewer One")

    def test_manual_recording_requires_approval_and_reference_then_locks_invoice(self):
        invoice_id = self.one()
        reference = {"company": COMPANY, "voucher_type": "Purchase", "voucher_number": "PUR-42", "voucher_date": "2026-10-08"}
        with self.assertRaises(self.s.Problem): self.action(invoice_id, "mark_manual", **reference)
        self.approve(invoice_id)
        with self.assertRaises(self.s.Problem): self.action(invoice_id, "mark_manual", **{**reference, "voucher_number": ""})
        self.action(invoice_id, "mark_manual", **reference)
        self.assertEqual("manually_recorded", self.s.get_invoice(invoice_id)["status"])
        manual = json.loads(self.s.get_invoice(invoice_id)["manual_json"])
        self.assertIn("not checked against Tally", manual["verification"])
        with self.assertRaises(self.s.Problem): self.edit(invoice_id)
        with self.assertRaises(self.s.Problem): self.action(invoice_id, "reopen")
        self.action(invoice_id, "record_correction_followup")
        self.assertEqual("manually_recorded", self.s.get_invoice(invoice_id)["status"])
        exported = self.call(self.s.make_export, {"kind": "outstanding"}, "Reviewer One")
        self.assertEqual(0, exported["count"])
        other = self.one(1)
        self.approve(other)
        with self.assertRaises(self.s.Problem): self.action(other, "mark_manual", **reference)

    def test_business_duplicate_blocked_then_documented_closure_resolves(self):
        first = self.one()
        second = self.one(changed=True)
        self.assertNotEqual(first, second)
        for invoice_id in (first, second):
            self.assertIn("POTENTIAL_DUPLICATE", {x["code"] for x in self.s.detail(invoice_id)["checks"]})
            with self.assertRaises(self.s.Problem): self.approve(invoice_id)
        self.action(second, "mark_duplicate", duplicate_of=first)
        self.assertEqual("rejected_closed", self.s.get_invoice(second)["status"])
        self.approve(first)
        self.assertEqual("approved_awaiting_entry", self.s.get_invoice(first)["status"])

    def test_approved_export_email_blocked_if_new_duplicate_arrives(self):
        first = self.one()
        self.approve(first)
        export = self.call(self.s.make_export, {"kind": "approved"}, "Reviewer One")
        self.one(changed=True)
        self.assertIn("POTENTIAL_DUPLICATE", {x["code"] for x in self.s.detail(first)["checks"]})
        with self.assertRaises(self.s.Problem):
            self.call(self.s.queue_email, export["id"],
                      {"sender": "sender@example.com", "to": "reviewer@example.com"}, "Reviewer One")

    def test_replacement_keeps_original_tracking_and_all_documents(self):
        target = self.one(14)
        self.action(target, "return")
        fixed = copy.deepcopy(FIXTURES[14])
        fixed["invoice_total"] -= 700
        replacement_name = "15_lumen_reissued_corrected_total.pdf"
        donor = self.one(14, data=fixed, changed=True, filename=replacement_name)
        self.action(target, "link_replacement", replacement_id=donor)
        detail = self.s.detail(target)
        self.assertEqual(2, detail["invoice"]["current_version"])
        self.assertEqual(fixed["invoice_total"], detail["data"]["invoice_total"])
        self.assertEqual(2, len(detail["documents"]))
        self.assertEqual(replacement_name, detail["invoice"]["source_file"])
        self.assertEqual(FIXTURES[14]["source_file"], detail["invoice"]["original_source_file"])
        self.assertEqual(replacement_name, detail["data"]["source_file"])
        report_row = dict(zip(self.s.REPORT_HEADERS, self.s.invoice_report_row(self.s.get_invoice(target))))
        self.assertEqual(replacement_name, report_row["Source filename"])
        self.assertEqual("rejected_closed", self.s.get_invoice(donor)["status"])
        self.assertEqual(FIXTURES[14]["invoice_total"], self.s.get_version(target, 1)["data"]["invoice_total"])
        self.approve(target)
        self.assertEqual("approved_awaiting_entry", self.s.get_invoice(target)["status"])

    def test_next_batch_carries_unresolved_and_excludes_recorded_opening(self):
        pending = self.one(0)
        self.action(pending, "hold")
        recorded = self.one(1)
        self.approve(recorded)
        self.action(recorded, "mark_manual", company=COMPANY, voucher_type="Purchase",
                    voucher_number="P001", voucher_date="2026-10-08")
        self.clear_input()
        self.add_pdf(2)
        batch = self.start()
        saved = self.s.row("SELECT * FROM batches WHERE id=?", (batch["batch_id"],))
        opening = json.loads(saved["opening_json"])
        self.assertEqual([{"id": pending, "status": "on_hold"}],
                         [{"id": item["id"], "status": item["status"]} for item in opening])
        self.result(batch, batch["files"][0], FIXTURES[2])
        self.finish(batch)
        report = self.call(self.s.make_export, {"kind": "outstanding"}, "Reviewer One")
        self.assertEqual(2, report["count"])

    def test_interrupted_batch_closes_pending_extractions_and_retries(self):
        self.add_pdf(0)
        self.add_pdf(1)
        batch = self.start()
        self.result(batch, batch["files"][0], FIXTURES[0])
        finished = self.finish(batch, reason="Model stopped during the second PDF", interrupted=True)
        self.assertEqual("interrupted", finished["status"])
        self.assertEqual(1, finished["summary"]["errors"])
        failed = batch["files"][1]["invoice_id"]
        self.assertEqual("processing_problem", self.s.get_invoice(failed)["status"])
        again = self.start()
        self.assertEqual(1, len(again["files"]))
        self.assertEqual(failed, again["files"][0]["invoice_id"])
        self.assertEqual(2, again["files"][0]["version_id"])
        self.result(again, again["files"][0], FIXTURES[1])
        self.finish(again)

    def test_backup_restore_preserves_state_and_quarantines_pending_email(self):
        invoice_id = self.one()
        self.approve(invoice_id)
        export = self.call(self.s.make_export, {"kind": "approved"}, "Reviewer One")
        # Only writes a queue file; the Outlook helper is not running in this test.
        queued = self.call(self.s.queue_email, export["id"], {"sender": "sender@example.com", "to": "reviewer@example.com"}, "Reviewer One")
        self.s.DB.commit()
        backup = self.s.create_backup()
        backup_file = self.s.ROOT / "backups" / backup["filename"]
        with zipfile.ZipFile(backup_file) as z:
            manifest = json.loads(z.read("manifest.json"))
            self.assertIn("database/invoice_control_v2.db", manifest["files"])
            self.assertTrue(any(x.startswith("archive/") for x in manifest["files"]))
        self.action(invoice_id, "hold")
        self.s.DB.close()
        self.s.restore_backup(backup_file, True)
        self.s.init_db()
        self.assertEqual("approved_awaiting_entry", self.s.get_invoice(invoice_id)["status"])
        self.assertEqual("unknown", self.s.row("SELECT * FROM email_jobs WHERE id=?", (queued["job_id"],))["status"])
        self.assertEqual([], list((self.s.ROOT / "output/outlook").glob("job_*.json")))
        self.assertTrue(list((self.s.ROOT / "output/outlook").glob("job_*.restored")))
        self.assertGreaterEqual(len(list((self.s.ROOT / "backups").glob("*.zip"))), 2)

    def test_restore_rejects_no_confirmation_tampering_and_path_escape(self):
        self.one()
        self.s.DB.commit()
        backup = self.s.create_backup()
        source = self.s.ROOT / "backups" / backup["filename"]
        with self.assertRaises(self.s.Problem): self.s.restore_backup(source, False)
        with zipfile.ZipFile(source) as z:
            contents = {name: z.read(name) for name in z.namelist()}
        manifest = json.loads(contents["manifest.json"])
        archive_name = next(x for x in manifest["files"] if x.startswith("archive/"))
        tampered = self.s.ROOT / "backups/tampered.zip"
        with zipfile.ZipFile(tampered, "w") as z:
            for name, raw in contents.items():
                z.writestr(name, b"tampered" if name == archive_name else raw)
        with self.assertRaises(self.s.Problem): self.s.restore_backup(tampered, True)
        evil = self.s.ROOT / "backups/unsafe.zip"
        manifest["files"]["output/../../escaped.txt"] = hashlib.sha256(b"escape").hexdigest()
        with zipfile.ZipFile(evil, "w") as z:
            for name, raw in contents.items():
                z.writestr(name, json.dumps(manifest) if name == "manifest.json" else raw)
            z.writestr("output/../../escaped.txt", b"escape")
        with self.assertRaises(self.s.Problem): self.s.restore_backup(evil, True)
        self.assertFalse((self.s.ROOT.parent / "escaped.txt").exists())
        self.assertEqual(1, len(self.s.rows("SELECT * FROM invoices")))


if __name__ == "__main__":
    unittest.main()
