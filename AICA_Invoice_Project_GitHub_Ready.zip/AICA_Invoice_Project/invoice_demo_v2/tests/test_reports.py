"""Run with python -m unittest discover -s tests -p test_reports.py.

Structural/safety tests have no dependencies. When available, openpyxl is used
read-only to check native workbook interpretation; it is not an app dependency.
"""
from datetime import date, datetime
from decimal import Decimal
from pathlib import Path
import sys
import tempfile
import unittest
from xml.etree import ElementTree as ET
from zipfile import ZipFile

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))
from reports import write_xlsx

try:
    from openpyxl import load_workbook
except ImportError:
    load_workbook = None


class ReportsTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / "report.xlsx"

    def tearDown(self):
        self.temp.cleanup()

    def sample(self):
        return [dict(name="Approved Entries", headers=["Invoice", "Debit (INR)", "Credit (INR)", "Notes", "Date"], rows=[
            ["000123", Decimal("1180.25"), 0, '=HYPERLINK("https://example.invalid")', date(2026, 10, 8)],
            ["INV & <2>", 0, 1180.25, "+cmd|' /C calc'!A0", datetime(2026, 10, 8, 14, 30)],
            ["control\x00\x0btest", -25, None, "पहली लाइन\nSecond line", None],
            ["12345678901234567890", 12345678901234567890, 1, "@SUM(1,1)", None],
        ], widths=[22, 20, 20, 48, 24]), dict(name="Outstanding", headers=["Status", "Reason"], rows=[])]

    def test_valid_xml_no_formula_no_external_relationships(self):
        write_xlsx(self.path, self.sample())
        with ZipFile(self.path) as archive:
            self.assertIsNone(archive.testzip())
            for member in archive.namelist():
                if member.endswith((".xml", ".rels")):
                    root = ET.fromstring(archive.read(member))
                    self.assertFalse(any(node.tag.endswith("}f") for node in root.iter()))
                    self.assertFalse(any(node.get("TargetMode") == "External" for node in root.iter()))
            root = ET.fromstring(archive.read("xl/worksheets/sheet1.xml"))
            ns = {"s": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
            self.assertEqual(root.find("s:autoFilter", ns).get("ref"), "A1:E5")
            self.assertEqual(root.find("s:sheetViews/s:sheetView/s:pane", ns).get("state"), "frozen")

    @unittest.skipIf(load_workbook is None, "Optional openpyxl compatibility reader unavailable")
    def test_independent_reader_values_and_styles(self):
        write_xlsx(self.path, self.sample())
        book = load_workbook(self.path)
        self.addCleanup(book.close)
        self.assertEqual(book.sheetnames, ["Approved Entries", "Outstanding"])
        sheet = book.worksheets[0]
        self.assertEqual(sheet["A2"].value, "000123")
        self.assertEqual(sheet["B2"].value, 1180.25)
        self.assertEqual(sheet["B4"].value, -25)
        self.assertEqual(sheet["B5"].value, "12345678901234567890")
        self.assertEqual(sheet["D2"].data_type, "s")
        self.assertTrue(sheet["D2"].value.startswith("=HYPERLINK"))
        self.assertEqual(sheet["A4"].value, "controltest")
        self.assertEqual(sheet["E2"].value, datetime(2026, 10, 8))
        self.assertEqual(sheet["E3"].value, datetime(2026, 10, 8, 14, 30))
        self.assertEqual(sheet.freeze_panes, "A2")
        self.assertTrue(sheet["A1"].font.bold)
        self.assertTrue(sheet["D2"].alignment.wrap_text)
        self.assertIn("#,##0.00", sheet["B2"].number_format)
        self.assertEqual(book.worksheets[1].max_row, 1)

    def test_invalid_write_does_not_replace_existing_report(self):
        self.path.write_bytes(b"existing")
        with self.assertRaises(ValueError):
            write_xlsx(self.path, [dict(name="Bad", headers=["Value"], rows=[[float("nan")]])])
        self.assertEqual(self.path.read_bytes(), b"existing")
        self.assertEqual(list(self.path.parent.glob(".report-*")), [])

    def test_names_and_shape_validation(self):
        write_xlsx(self.path, [dict(name="a/b", headers=["x"], rows=[]), dict(name="a:b", headers=["x"], rows=[[1]])])
        with ZipFile(self.path) as archive:
            root = ET.fromstring(archive.read("xl/workbook.xml"))
            names = [node.get("name") for node in root.iter() if node.tag.endswith("}sheet")]
            self.assertEqual(names, ["a b", "a b (2)"])
        with self.assertRaises(ValueError):
            write_xlsx(self.path, [dict(headers=["x"], rows=[[1, 2]])])
        with self.assertRaises(ValueError):
            write_xlsx(self.path, [])


if __name__ == "__main__":
    unittest.main()
