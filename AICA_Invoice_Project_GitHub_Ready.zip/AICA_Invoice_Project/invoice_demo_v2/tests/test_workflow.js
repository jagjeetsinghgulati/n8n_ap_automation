'use strict';
// Unit checks run Code-node source and expressions from the delivered JSON.
// The mocked n8n item lookup tests lineage contracts, not the n8n engine itself.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { test } = require('node:test');
const workflow = JSON.parse(fs.readFileSync(path.join(__dirname, '../workflows/Local_Invoice_V2_Workflow.json'), 'utf8'));
const nodes = new Map(workflow.nodes.map(n => [n.name, n]));
const settings = { approvalApiUrl: 'http://invoice-approval-v2:8787', apiToken: 'test-local-token-not-a-secret', ollamaBaseUrl: 'http://host.docker.internal:11434', model: 'qwen2.5:7b', companyName: 'Test Company', asOfDate: '2026-10-08' };
const batch = {
  batch_id: 'B-20261008-000001',
  files: [
    { invoice_id: 'INV-000001', version_id: 3, source_file: 'Alpha invoice.pdf', archive_path: '/files/invoice_demo_v2/archive/a.pdf', sha256: 'a'.repeat(64) },
    { invoice_id: 'INV-000002', version_id: 8, source_file: 'Beta invoice.pdf', archive_path: '/files/invoice_demo_v2/archive/b.pdf', sha256: 'b'.repeat(64) },
  ],
};
const item = json => ({ json });
function lookup(outputs) {
  return name => {
    assert.ok(outputs[name], 'Mocked named output exists: ' + name);
    return { first: () => outputs[name][0], all: () => outputs[name], itemMatching: index => {
      assert.ok(outputs[name][index], 'Matched item exists: ' + name + '[' + index + ']');
      return outputs[name][index];
    } };
  };
}
function run(name, input, outputs = {}) {
  const n = nodes.get(name);
  assert.equal(n.type, 'n8n-nodes-base.code');
  return new Function('$input', '$', '$execution', n.parameters.jsCode)(
    { first: () => input[0], all: () => input },
    lookup({ 'Demo Settings': [item(settings)], ...outputs }),
    { id: 'execution-123' },
  );
}
function expression(text, data, outputs = {}) {
  assert.ok(text.startsWith('={{ ') && text.endsWith(' }}'), 'Expected n8n expression');
  return new Function('$', '$json', 'return (' + text.slice(3, -2).trim() + ');')(
    lookup({ 'Demo Settings': [item(settings)], ...outputs }), data,
  );
}
function registered() { return run('Registered Files', [item(batch)]); }
function assertIdentity(items) {
  assert.equal(items.length, 2);
  items.forEach((entry, index) => {
    for (const key of ['invoice_id', 'version_id', 'source_file']) assert.equal(entry.json[key], batch.files[index][key]);
    assert.equal(entry.json.batch_id, batch.batch_id);
  });
}
const invoice = {
  invoice_number: 'A-100', supplier_name: 'Alpha Components', supplier_gstin: '06ABCDE1234F1Z5', buyer_name: 'Test Company',
  invoice_date: '2026-10-01', due_date: '2026-10-31', currency: 'INR', document_type: 'INVOICE', description: 'Invoice for components',
  notes: null, category: 'Other', category_reason: 'Components purchase', taxable_value: 1000, cgst: 90, sgst: 90, igst: 0,
  other_charges: 0, round_off: 0, invoice_total: 1180,
  line_items: [{ description: 'Metal component', quantity: 10, unit_price: 100, taxable_amount: 1000 }],
};

test('every Code node compiles and all graph / named-node references exist', () => {
  assert.equal(nodes.size, workflow.nodes.length, 'Node names must be unique');
  for (const n of nodes.values()) {
    if (n.type === 'n8n-nodes-base.code') assert.doesNotThrow(() => new Function('$input', '$', '$execution', n.parameters.jsCode), n.name);
    for (const ref of JSON.stringify(n.parameters).matchAll(/\$\('([^']+)'\)/g)) assert.ok(nodes.has(ref[1]), n.name + ' refers to missing node ' + ref[1]);
  }
  for (const [from, channels] of Object.entries(workflow.connections)) {
    assert.ok(nodes.has(from), 'Connection source exists: ' + from);
    for (const groups of Object.values(channels)) for (const group of groups) for (const edge of group) {
      assert.ok(nodes.has(edge.node), 'Connection target exists: ' + edge.node);
      assert.equal(edge.type, 'main');
      assert.equal(edge.index, 0);
    }
  }
  assert.equal(workflow.settings.timezone, 'Asia/Kolkata');
});

test('two distinct invoice and version identities survive valid and failed model outputs', () => {
  const files = registered();
  assertIdentity(files);
  const read = files.map((f, index) => ({ json: {}, binary: { data: { fileName: f.json.source_file, data: 'pdf-' + index } } }));
  const context = run('File Context', read, { 'New Files To Process': files });
  assertIdentity(context);
  assert.equal(context[1].binary, read[1].binary);
  context.forEach((x, i) => assert.deepEqual(x.pairedItem, { item: i }));
  const texts = files.map(f => item({ text: ('Supplier ' + f.json.source_file + ' INR invoice details 1000 90 90 1180. ').repeat(3) }));
  const prepared = run('Prepare Extraction', texts, { 'File Context': context });
  assertIdentity(prepared);
  prepared.forEach((x, i) => {
    assert.deepEqual(x.pairedItem, { item: i });
    assert.equal(x.json.request.model, 'qwen2.5:7b');
    assert.deepEqual(x.json.sourceIssues, []);
    assert.equal(x.json.request.stream, false);
  });
  const responses = [item({ response: JSON.stringify(invoice) }), item({ error: { message: 'Ollama unavailable' } })];
  const parsed = run('Parse Invoice JSON', responses, { 'Prepare Extraction': prepared });
  assertIdentity(parsed);
  parsed.forEach((x, i) => assert.deepEqual(x.pairedItem, { item: i }));
  assert.equal(parsed[0].json.invoice_total, 1180);
  assert.equal(parsed[0].json.invoice_number, 'A-100');
  assert.equal(parsed[0].json.line_items[0].quantity, 10);
  assert.equal(parsed[0].json.llm_response, responses[0].json.response);
  assert.deepEqual(parsed[0].json.flags, []);
  assert.ok(parsed[1].json.flags.includes('LLM_EXTRACTION_ERROR'));
  assert.equal(parsed[1].json.invoice_total, null);
  assert.equal(parsed[1].json.invoice_number, null);
  const save = nodes.get('Save V2 Extraction').parameters;
  parsed.forEach((x, i) => {
    const body = expression(save.jsonBody, x.json);
    assert.equal(body.invoice_id, batch.files[i].invoice_id);
    assert.equal(body.version_id, batch.files[i].version_id);
    assert.equal(body.batch_id, batch.batch_id);
    assert.equal(body.data, x.json);
  });
});

test('read failures, short text and truncation retain distinct source flags', () => {
  const files = registered();
  const context = run('File Context', [item({}), item({ error: 'Cannot read PDF' })], { 'New Files To Process': files });
  assert.ok(context[0].json.read_error, 'Missing binary becomes a readable failure');
  assert.equal(context[1].json.read_error, 'Cannot read PDF');
  const prepared = run('Prepare Extraction', [item({ error: 'PDF parser failed' }), item({ text: 'X'.repeat(25000) })], { 'File Context': context });
  assertIdentity(prepared);
  assert.deepEqual(prepared[0].json.sourceIssues, ['PDF_READ_ERROR', 'NO_READABLE_TEXT']);
  assert.deepEqual(prepared[1].json.sourceIssues, ['PDF_READ_ERROR', 'TEXT_TRUNCATED']);
  assert.equal(prepared[1].json.raw_text.length, 25000, 'Full raw text remains audit evidence');
  assert.equal(prepared[1].json.request.prompt.split('BEGIN DOCUMENT DATA\n')[1].split('\nEND DOCUMENT DATA')[0].length, 24000);
  const parsed = run('Parse Invoice JSON', [item({ response: '{broken' }), item({ response: '[]' })], { 'Prepare Extraction': prepared });
  assertIdentity(parsed);
  assert.deepEqual(parsed[0].json.flags, ['PDF_READ_ERROR', 'NO_READABLE_TEXT', 'LLM_EXTRACTION_ERROR']);
  assert.deepEqual(parsed[1].json.flags, ['PDF_READ_ERROR', 'TEXT_TRUNCATED', 'LLM_EXTRACTION_ERROR']);
  for (const name of ['Read Archived PDFs', 'Extract PDF Text', 'Qwen Extract Invoice']) assert.equal(nodes.get(name).onError, 'continueRegularOutput');
});

test('missing or invalid numeric model values never become zero', () => {
  const prepared = registered().map(x => item({ ...x.json, sourceIssues: [], raw_text: 'Document text' }));
  const parsed = run('Parse Invoice JSON', [item({ response: JSON.stringify({ ...invoice, invoice_total: '1180', cgst: null }) }), item({ response: JSON.stringify({ ...invoice, category: 'Unknown invented category' }) })], { 'Prepare Extraction': prepared });
  assert.equal(parsed[0].json.invoice_total, null);
  assert.equal(parsed[0].json.cgst, null);
  assert.ok(parsed[0].json.flags.includes('INVALID_NUMBER_INVOICE_TOTAL'));
  assert.equal(parsed[1].json.category, 'Other');
});

test('empty batches bypass extraction and still complete with the registered batch ID', () => {
  const emptyBatch = { batch_id: 'B-EMPTY', files: [] };
  const empty = run('Registered Files', [item(emptyBatch)]);
  assert.deepEqual(empty, [item({ batch_id: 'B-EMPTY', hasFiles: false })]);
  const condition = nodes.get('New Files To Process').parameters.conditions.conditions[0];
  assert.equal(expression(condition.leftValue, empty[0].json), false);
  assert.equal(workflow.connections['New Files To Process'].main[1][0].node, 'Prepare Batch Completion');
  assert.equal(workflow.connections['New Files To Process'].main[0][0].node, 'Read Archived PDFs');
  const complete = run('Prepare Batch Completion', empty, { 'Register V2 Batch': [item(emptyBatch)] });
  assert.deepEqual(complete, [item({ batch_id: 'B-EMPTY' })]);
  assert.deepEqual(expression(nodes.get('Complete V2 Batch').parameters.jsonBody, complete[0].json), { batch_id: 'B-EMPTY' });
  const next = run('Open Approval Screen', [item({ batch_id: 'B-EMPTY', status: 'completed' })]);
  assert.equal(next[0].json.batch_id, 'B-EMPTY');
  assert.ok(next[0].json.reportsFolder.includes('/invoice_demo_v2/output'));
});

test('HTTP calls are isolated to V2 ingest and local Ollama; no automatic email or posting', () => {
  const expected = {
    'Register V2 Batch': 'http://invoice-approval-v2:8787/api/ingest/start',
    'Save V2 Extraction': 'http://invoice-approval-v2:8787/api/ingest/result',
    'Complete V2 Batch': 'http://invoice-approval-v2:8787/api/ingest/finish',
    'Qwen Extract Invoice': 'http://host.docker.internal:11434/api/generate',
  };
  const requests = workflow.nodes.filter(n => n.type === 'n8n-nodes-base.httpRequest');
  assert.equal(requests.length, Object.keys(expected).length);
  for (const n of requests) {
    assert.equal(expression(n.parameters.url, {}), expected[n.name]);
    assert.equal(n.parameters.method, 'POST');
    if (n.name !== 'Qwen Extract Invoice') {
      const auth = n.parameters.headerParameters.parameters.find(h => h.name === 'Authorization');
      assert.equal(expression(auth.value, {}), 'Bearer ' + settings.apiToken);
    }
  }
  for (const f of batch.files) assert.equal(expression(nodes.get('Read Archived PDFs').parameters.fileSelector, f), f.archive_path);
  assert.ok(!JSON.stringify(workflow).includes('/invoice_demo/'), 'No V1 directory references');
  assert.ok(!workflow.nodes.some(n => /emailSend|microsoftOutlook|executeCommand/.test(n.type)), 'No autonomous mail or shell node');
});

test('settings prevent importing an unconfigured template and bind the execution key to V2', () => {
  assert.throws(() => run('Demo Settings', []), /SETUP_V2\.cmd/);
  const code = nodes.get('Demo Settings').parameters.jsCode.replace('__V2_API_TOKEN__', 'test-token-filled-by-setup');
  const output = new Function('$execution', code)({ id: '12345' });
  assert.equal(output[0].json.runKey, 'V2_12345');
  assert.equal(output[0].json.model, 'qwen2.5:7b');
  assert.match(output[0].json.asOfDate, /^\d{4}-\d{2}-\d{2}$/);
  assert.throws(() => run('Registered Files', [item({ files: [] })]), /Unexpected approval service response/);
});
