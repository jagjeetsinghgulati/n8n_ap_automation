"""Live local HTTP acceptance tests. No external services, email or dependencies.

Run: python -m unittest discover -s tests -p test_http.py -v
The actual server runs in a subprocess against a temporary database and folders.
"""
from copy import deepcopy
from hashlib import sha256
from http.cookiejar import CookieJar
from io import BytesIO
import json
import os
from pathlib import Path
import socket
import sqlite3
import subprocess
import sys
import tempfile
import time
import unittest
from urllib.error import HTTPError, URLError
from urllib.request import Request, build_opener, HTTPCookieProcessor
from xml.etree import ElementTree as ET
from zipfile import ZipFile


APP = Path(__file__).resolve().parents[1] / "app"
TOKEN = "http-test-token-012345678901234567890"
PASSWORD = "http-test-password-0123456789"
COMPANY = "Northstar Precision Components Pvt Ltd"


def fixture_pdf():
    """Generate a valid one-page selectable-text PDF using only the standard library."""
    stream = b"BT /F1 12 Tf 50 780 Td (Fictional HTTP fixture invoice IV-2026-001 total INR 1180.00) Tj ET"
    objects = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
        b"<< /Length " + str(len(stream)).encode() + b" >>\nstream\n" + stream + b"\nendstream",
    ]
    body = bytearray(b"%PDF-1.4\n")
    offsets = []
    for number, obj in enumerate(objects, 1):
        offsets.append(len(body))
        body.extend(str(number).encode() + b" 0 obj\n" + obj + b"\nendobj\n")
    start = len(body)
    body.extend(b"xref\n0 6\n0000000000 65535 f \n")
    for offset in offsets:
        body.extend(f"{offset:010} 00000 n \n".encode())
    body.extend(f"trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n{start}\n%%EOF\n".encode())
    return bytes(body)


def fixture_data():
    return dict(
        supplier_name="Fixture Stationery Private Limited", supplier_gstin=None,
        buyer_name=COMPANY, invoice_number="IV-2026-001", invoice_date="2026-10-01",
        due_date="2026-10-31", currency="INR", document_type="INVOICE",
        taxable_value=1000, cgst=90, sgst=90, igst=0, other_charges=0,
        round_off=0, invoice_total=1180, category="Office supplies",
        category_reason="Stationery purchase", description="Printed stationery",
        notes="Fictional test fixture only", raw_text="Fixture Stationery IV-2026-001 INR 1180.00",
        flags=[], line_items=[dict(description="Paper packs", quantity=10, unit_price=100, taxable_amount=1000)],
    )


class HTTPAcceptanceTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name) / "files"
        self.data = Path(self.temp.name) / "database"
        (self.root / "input").mkdir(parents=True)
        with socket.socket() as sock:
            sock.bind(("127.0.0.1", 0))
            self.port = sock.getsockname()[1]
        self.url = f"http://127.0.0.1:{self.port}"
        env = dict(os.environ, ROOT_DIR=str(self.root), DATA_DIR=str(self.data),
                   PORT=str(self.port), INVOICE_API_TOKEN=TOKEN,
                   INVOICE_USER="reviewer", INVOICE_PASSWORD=PASSWORD)
        self.log = open(Path(self.temp.name) / "server.log", "w+b")
        self.addCleanup(self.log.close)
        self.proc = subprocess.Popen([sys.executable, str(APP / "server.py")],
                                     env=env, stdout=self.log, stderr=self.log)
        self.addCleanup(self.stop_server)
        self.browser = build_opener(HTTPCookieProcessor(CookieJar()))
        self.workflow = build_opener()
        self.csrf = None
        deadline = time.monotonic() + 10
        while time.monotonic() < deadline:
            if self.proc.poll() is not None:
                self.fail("Server exited during startup: " + self.server_log())
            try:
                code, _, body = self.request("/api/health", opener=self.workflow)
                if code == 200 and body.get("ok"):
                    break
            except (URLError, OSError):
                time.sleep(0.05)
        else:
            self.fail("Server did not become healthy: " + self.server_log())

    def stop_server(self):
        if self.proc.poll() is None:
            self.proc.terminate()
            try:
                self.proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.proc.kill()
                self.proc.wait(timeout=5)

    def server_log(self):
        self.log.flush()
        self.log.seek(0)
        return self.log.read().decode("utf-8", "replace")

    def request(self, path, payload=None, *, opener=None, bearer=False,
                csrf=True, raw=None, content_type="application/json"):
        headers = {}
        body = None
        if payload is not None or raw is not None:
            body = raw if raw is not None else json.dumps(payload).encode()
            headers["Content-Type"] = content_type
            if csrf and self.csrf:
                headers["X-CSRF-Token"] = self.csrf
        if bearer:
            headers["Authorization"] = "Bearer " + TOKEN
        request = Request(self.url + path, data=body, headers=headers)
        try:
            response = (opener or self.browser).open(request, timeout=10)
        except HTTPError as error:
            response = error
        with response:
            data = response.read()
            if "application/json" in response.headers.get("Content-Type", ""):
                data = json.loads(data)
            return response.status, response.headers, data

    def assert_status(self, wanted, result):
        self.assertEqual(result[0], wanted, f"Unexpected HTTP response: {result}\n{self.server_log()}")
        return result[2]

    def login(self):
        result = self.request("/api/login", dict(username="reviewer", password=PASSWORD))
        response = self.assert_status(200, result)
        cookie = result[1].get("Set-Cookie", "")
        self.assertIn("HttpOnly", cookie)
        self.assertIn("SameSite=Strict", cookie)
        self.csrf = response["csrf"]
        return response

    def ingest(self):
        self.pdf = fixture_pdf()
        (self.root / "input" / "fixture.pdf").write_bytes(self.pdf)
        settings = dict(runKey="http-test-run", model="qwen2.5:7b", companyName=COMPANY, asOfDate="2026-10-08")
        start = self.assert_status(200, self.request("/api/ingest/start", settings, opener=self.workflow, bearer=True))
        self.assertEqual(start["received"], 1)
        self.assertEqual(len(start["files"]), 1)
        repeat = self.assert_status(200, self.request("/api/ingest/start", settings, opener=self.workflow, bearer=True))
        self.assertEqual(repeat["batch_id"], start["batch_id"])
        self.assertEqual(repeat["files"], start["files"])
        job = start["files"][0]
        self.assertEqual(job["sha256"], sha256(self.pdf).hexdigest())
        payload = {"batch_id": start["batch_id"], "invoice_id": job["invoice_id"], "version_id": job["version_id"], "data": fixture_data()}
        wrong = dict(payload, batch_id="not-the-registered-batch")
        self.assert_status(409, self.request("/api/ingest/result", wrong, opener=self.workflow, bearer=True))
        result = self.assert_status(200, self.request("/api/ingest/result", payload, opener=self.workflow, bearer=True))
        self.assertEqual(result["status"], "awaiting_approval")
        replay = deepcopy(payload)
        replay["data"]["invoice_total"] = 999
        response = self.assert_status(200, self.request("/api/ingest/result", replay, opener=self.workflow, bearer=True))
        self.assertTrue(response["idempotent"])
        finished = self.assert_status(200, self.request("/api/ingest/finish", {"batch_id": start["batch_id"]}, opener=self.workflow, bearer=True))
        self.assertEqual(finished["status"], "completed")
        self.assertEqual(finished["summary"]["extracted"], 1)
        self.assertEqual(len(finished["reports"]), 2)
        return start, job

    def test_authentication_csrf_and_invalid_requests_do_not_mutate(self):
        for path in ("/", "/style.css", "/app.js"):
            result = self.request(path)
            self.assert_status(200, result)
            self.assertGreater(len(result[2]), 100)
        self.assert_status(401, self.request("/api/state"))
        self.assert_status(401, self.request("/api/documents/DOC-00000000"))
        self.assert_status(401, self.request("/api/ingest/start", {"runKey": "unauth"}, opener=self.workflow))
        self.assert_status(401, self.request("/api/login", {"username": "reviewer", "password": "wrong"}))
        self.login()
        before = self.assert_status(200, self.request("/api/state"))
        self.assertEqual(before["invoices"], [])
        self.assert_status(403, self.request("/api/exports", {"kind": "outstanding"}, csrf=False))
        # A workflow token grants ingestion only, never review or approval access.
        self.assert_status(401, self.request("/api/state", opener=self.workflow, bearer=True))
        self.assert_status(401, self.request("/api/invoices/INV-000001/action", {"version": 1, "action": "approve"}, opener=self.workflow, bearer=True))
        # A reviewer session is not itself a workflow API credential.
        self.assert_status(401, self.request("/api/ingest/start", {"runKey": "wrong-role"}))
        self.assert_status(400, self.request("/api/exports", raw=b'{"kind":'))
        self.assert_status(400, self.request("/api/exports", raw=b"[]"))
        self.assert_status(415, self.request("/api/exports", raw=b"{}", content_type="text/plain"))
        self.assert_status(400, self.request("/api/exports", {"kind": "invalid"}))
        after = self.assert_status(200, self.request("/api/state"))
        for field in ("batches", "invoices", "exports", "email_jobs"):
            self.assertEqual(after[field], before[field])
        self.assert_status(200, self.request("/api/logout", {}))
        self.assert_status(401, self.request("/api/state"))

    def test_invoice_approval_export_manual_recording_and_backup(self):
        self.login()
        batch, job = self.ingest()
        iid = job["invoice_id"]
        endpoint = "/api/invoices/" + iid
        detail = self.assert_status(200, self.request(endpoint))
        self.assertEqual(detail["data"]["invoice_total"], 1180)
        self.assertEqual(detail["invoice"]["current_version"], 1)
        self.assertEqual(detail["invoice"]["status"], "awaiting_approval")
        self.assertFalse([c for c in detail["checks"] if c["severity"] == "block"])
        soft = [c["code"] for c in detail["checks"] if c["severity"] == "review"]
        self.assertIn("MISSING_GSTIN", soft)
        document = self.request("/api/documents/" + detail["documents"][0]["id"])
        self.assert_status(200, document)
        self.assertEqual(document[1].get("Content-Type"), "application/pdf")
        self.assertEqual(document[2], self.pdf)
        version = self.assert_status(200, self.request(f"/api/versions/{iid}/1"))
        self.assertEqual(version["data"], detail["data"])

        # Rejected approval/edit requests must not create decisions or versions.
        decision = dict(version=1, action="approve", reason="Checked original; registration clarification recorded", exception_codes=soft, ledger_confirmed=True)
        self.assert_status(400, self.request(endpoint + "/action", dict(decision, ledger_confirmed=False)))
        self.assert_status(400, self.request(endpoint + "/action", dict(decision, exception_codes=[])))
        self.assert_status(409, self.request(endpoint + "/action", dict(decision, version=99)))
        bad_data = dict(detail["data"], invoice_total={"not": "numeric"})
        self.assert_status(400, self.request(endpoint + "/edit", dict(version=1, reason="Invalid test correction", data=bad_data, entries=detail["entries"], voucher=detail["voucher"])))
        unchanged = self.assert_status(200, self.request(endpoint))
        self.assertEqual(unchanged["history"], detail["history"])
        self.assertEqual(unchanged["versions"], detail["versions"])
        approved = self.assert_status(200, self.request(endpoint + "/action", decision))
        self.assertEqual(approved["invoice"]["status"], "approved_awaiting_entry")
        self.assertEqual(approved["history"][0]["actor"], "reviewer")

        report = self.assert_status(200, self.request("/api/exports", {"kind": "approved"}))
        self.assertEqual(report["count"], 1)
        downloaded = self.request(report["url"])
        self.assert_status(200, downloaded)
        self.assertIn("attachment", downloaded[1].get("Content-Disposition"))
        with ZipFile(BytesIO(downloaded[2])) as archive:
            self.assertIsNone(archive.testzip())
            ns = {"s": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
            workbook = ET.fromstring(archive.read("xl/workbook.xml"))
            self.assertEqual([s.get("name") for s in workbook.find("s:sheets", ns)],
                             ["Approved Invoices", "Accounting Entries", "Read Me", "Status Totals", "Invoice Line Items"])
            sheets = [ET.fromstring(archive.read(name)) for name in archive.namelist() if name.startswith("xl/worksheets/")]
            self.assertFalse(any(sheet.findall(".//s:f", ns) for sheet in sheets))
            numbers = [float(n.text) for sheet in sheets for n in sheet.findall(".//s:c/s:v", ns)]
            self.assertIn(1180, numbers)
        self.assert_status(400, self.request("/api/exports", {"kind": "approved"}))
        after_export = self.assert_status(200, self.request(endpoint))
        self.assertEqual(after_export["invoice"]["export_id"], report["id"])
        self.assertEqual(after_export["invoice"]["status"], "approved_awaiting_entry")

        self.assert_status(400, self.request(endpoint + "/action", dict(version=1, action="mark_manual", company=COMPANY, voucher_type="Purchase", voucher_date="2026-10-08")))
        recorded = self.assert_status(200, self.request(endpoint + "/action", dict(version=1, action="mark_manual", company=COMPANY, voucher_type="Purchase", voucher_number="TEST-PUR-001", voucher_date="2026-10-08")))
        self.assertEqual(recorded["invoice"]["status"], "manually_recorded")
        self.assertEqual(recorded["invoice"]["manual_reference"]["voucher_number"], "TEST-PUR-001")
        outstanding = self.assert_status(200, self.request("/api/exports", {"kind": "outstanding"}))
        self.assertEqual(outstanding["count"], 0)

        backup = self.assert_status(200, self.request("/api/backup", {}))
        backup_bytes = self.assert_status(200, self.request(backup["url"]))
        with ZipFile(BytesIO(backup_bytes)) as archive:
            manifest = json.loads(archive.read("manifest.json"))
            self.assertIn("database/invoice_control_v2.db", manifest["files"])
            self.assertTrue(any(name.startswith("archive/") for name in manifest["files"]))
            self.assertTrue(any(name.endswith(report["filename"]) for name in manifest["files"]))
            for name, digest in manifest["files"].items():
                self.assertEqual(sha256(archive.read(name)).hexdigest(), digest)
            database_copy = Path(self.temp.name) / "backup-database.db"
            database_copy.write_bytes(archive.read("database/invoice_control_v2.db"))
        with sqlite3.connect(database_copy) as connection:
            self.assertEqual(connection.execute("PRAGMA integrity_check").fetchone()[0], "ok")
            status = connection.execute("SELECT status FROM invoices WHERE id=?", (iid,)).fetchone()[0]
            self.assertEqual(status, "manually_recorded")
        state = self.assert_status(200, self.request("/api/state"))
        self.assertEqual(state["email_jobs"], [])
        self.assertEqual(len(state["batches"]), 1)
        self.assert_status(200, self.request("/api/logout", {}))
        self.assert_status(401, self.request(backup["url"]))


if __name__ == "__main__":
    unittest.main()
