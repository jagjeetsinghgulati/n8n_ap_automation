@echo off
setlocal
powershell.exe -NoLogo -NoProfile -File "%~dp0scripts\Manage.ps1" -Action status
if errorlevel 1 echo Operation did not complete. Read the error above.
pause
