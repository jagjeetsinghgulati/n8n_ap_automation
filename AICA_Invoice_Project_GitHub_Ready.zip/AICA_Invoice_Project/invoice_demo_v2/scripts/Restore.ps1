param([string]$BackupName)
. (Join-Path $PSScriptRoot 'Common.ps1')
try {
    Assert-Docker
    $null = Read-V2Environment
    Write-Host 'RESTORE INVOICE V2 - replaces V2 database and archived records' -ForegroundColor Yellow
    Write-Host 'Close the V2 Outlook helper and stop any running V2 n8n execution first. V1 may remain running.'
    if (-not $BackupName) { $BackupName = Read-Host 'Enter the backup ZIP filename from the backups folder (filename only)' }
    if ([IO.Path]::GetFileName($BackupName) -ne $BackupName -or $BackupName -notmatch '^[A-Za-z0-9_.-]+\.zip$') { throw 'Use a plain ZIP filename from the V2 backups folder.' }
    if (-not (Test-Path -LiteralPath (Join-Path $script:V2Root ('backups\' + $BackupName)) -PathType Leaf)) { throw 'The backup ZIP was not found in the V2 backups folder.' }
    $confirm = Read-Host 'Type RESTORE V2 to confirm replacement of V2 records'
    if ($confirm -cne 'RESTORE V2') { Write-Host 'Restore cancelled.'; exit 0 }
    Invoke-V2Compose -Arguments @('stop','approval')
    try {
        Invoke-V2Compose -Arguments @('run','--rm','--no-deps','approval','python','/app/server.py','--restore',('/files/backups/' + $BackupName),'--confirm-replace')
    } catch {
        Write-Host 'Restore failed; V2 remains stopped. Preserve its data and inspect the error before restarting. V1 was not changed.' -ForegroundColor Red
        throw
    }
    Invoke-V2Compose -Arguments @('up','-d','approval')
    Wait-V2Ready
    Write-Host 'V2 restore completed. Compare counts and documents in the approval screen.' -ForegroundColor Green
    Write-Host 'Do not resend old Outlook jobs. Check Sent Items before making a fresh send request.'
} catch { Write-Host $_.Exception.Message -ForegroundColor Red; exit 1 }
