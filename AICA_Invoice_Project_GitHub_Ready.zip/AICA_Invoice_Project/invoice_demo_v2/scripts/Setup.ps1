. (Join-Path $PSScriptRoot 'Common.ps1')
try {
    Assert-Docker
    Write-Host 'INVOICE V2 - Separate approval and tracking setup' -ForegroundColor Cyan
    Write-Host "Folder: $script:V2Root"
    $raw = & docker inspect n8n 2>$null
    if ($LASTEXITCODE -ne 0) { throw 'The existing container named n8n was not found. Start your working n8n installation first.' }
    $container = @($raw | ConvertFrom-Json)[0]
    if (-not $container.State.Running) { throw 'The existing n8n container is stopped. Start it in Docker Desktop and run setup again.' }
    # The workflow returns paths below /files/invoice_demo_v2 in the EXISTING n8n mount.
    # Refuse a misplaced package rather than altering that mount or silently reading V1.
    $mounts = @($container.Mounts | Where-Object { $_.Destination -eq '/files' -and $_.Type -eq 'bind' })
    if ($mounts.Count -ne 1) { throw 'The existing n8n container must have one Windows folder bound to /files. V1 has not been changed.' }
    $hostSource = [string]$mounts[0].Source
    # Docker Desktop versions report either C:/... or its internal host mount path.
    if ($hostSource -match '^/(?:run/desktop/mnt/host|host_mnt)/([A-Za-z])/(.*)$') {
        $hostSource = $Matches[1] + ':/' + $Matches[2]
    }
    if ($hostSource -notmatch '^[A-Za-z]:[\\/]') { throw 'Could not identify the Windows source of the n8n /files mount. Ask for help identifying that folder; V1 has not been changed.' }
    $expectedRoot = [IO.Path]::GetFullPath((Join-Path $hostSource 'invoice_demo_v2')).TrimEnd('\','/')
    $actualRoot = [IO.Path]::GetFullPath($script:V2Root).TrimEnd('\','/')
    if ($actualRoot -ine $expectedRoot) { throw "Move the complete invoice_demo_v2 folder to $expectedRoot and run SETUP_V2.cmd there. This is required to match n8n's existing /files mount. No files or V1 settings were changed." }
    $networkName = $null
    foreach ($candidate in $container.NetworkSettings.Networks.PSObject.Properties.Name) {
        if ($candidate -in @('bridge','host','none')) { continue }
        $networkRaw = & docker network inspect $candidate 2>$null
        if ($LASTEXITCODE -ne 0) { continue }
        $network = @($networkRaw | ConvertFrom-Json)[0]
        if ($network.Driver -eq 'bridge') { $networkName = [string]$candidate; break }
    }
    if (-not $networkName -or $networkName -notmatch '^[A-Za-z0-9_.-]+$') { throw 'No usable user-defined bridge network was found on n8n. Send the network names shown in Docker Desktop for assistance; V1 has not been changed.' }
    $envPath = Join-Path $script:V2Root '.env'
    if (Test-Path -LiteralPath $envPath) {
        $values = Read-V2Environment
        if ($values.N8N_NETWORK -ne $networkName) { throw 'The saved V2 network differs from the current n8n network. Keep your .env and database; ask for help updating only N8N_NETWORK.' }
        Write-Host 'Existing credentials and database settings reused.'
    } else {
        $user = Read-Host 'Reviewer login name (press Enter for jagjeet)'
        if ([string]::IsNullOrWhiteSpace($user)) { $user = 'jagjeet' }
        if ($user -notmatch '^[A-Za-z][A-Za-z0-9_.-]{1,39}$') { throw 'Use a login name of 2-40 letters/numbers/dot/underscore/hyphen, starting with a letter.' }
        $values = @{ N8N_NETWORK=$networkName; INVOICE_API_TOKEN=(New-V2Secret 32); INVOICE_USER=$user; INVOICE_PASSWORD=(New-V2Secret 12) }
        $lines = @('N8N_NETWORK','INVOICE_API_TOKEN','INVOICE_USER','INVOICE_PASSWORD') | ForEach-Object { "$_=$($values[$_])" }
        [IO.File]::WriteAllText($envPath, (($lines -join "`r`n") + "`r`n"), $script:Utf8)
        Protect-V2File $envPath
        $credentials = "Invoice V2 local reviewer login`r`nURL: http://localhost:8787`r`nUsername: $($values.INVOICE_USER)`r`nPassword: $($values.INVOICE_PASSWORD)`r`n`r`nKeep this file and .env private. Credentials are reused on future starts.`r`nDo not send the Ready_To_Import_V2.json file to others: it contains your local API token.`r`n"
        $credentialsPath = Join-Path $script:V2Root 'LOCAL_LOGIN_PRIVATE.txt'
        [IO.File]::WriteAllText($credentialsPath, $credentials, $script:Utf8)
        Protect-V2File $credentialsPath
    }
    foreach ($folder in @('input','archive','output','output\outlook','backups')) { [void][IO.Directory]::CreateDirectory((Join-Path $script:V2Root $folder)) }
    $template = Join-Path $script:V2Root 'workflows\Local_Invoice_V2_Workflow.json'
    if (-not (Test-Path -LiteralPath $template)) { throw 'Workflow template missing. Extract the complete ZIP, then run SETUP_V2.cmd from the extracted invoice_demo_v2 folder.' }
    $content = [IO.File]::ReadAllText($template)
    if (-not $content.Contains('__V2_API_TOKEN__')) { throw 'Workflow template does not contain its setup placeholder. Do not use a previously personalised workflow as the template.' }
    $ready = $content.Replace('__V2_API_TOKEN__', [string]$values.INVOICE_API_TOKEN)
    $null = $ready | ConvertFrom-Json
    $readyPath = Join-Path $script:V2Root 'Ready_To_Import_V2.json'
    [IO.File]::WriteAllText($readyPath, $ready, $script:Utf8)
    Protect-V2File $readyPath
    Invoke-V2Compose -Arguments @('up','-d','approval')
    Wait-V2Ready
    Write-Host ''
    Write-Host 'V2 is ready. V1 was not modified.' -ForegroundColor Green
    Write-Host '1. Import Ready_To_Import_V2.json into n8n as a NEW workflow.'
    Write-Host '2. Read LOCAL_LOGIN_PRIVATE.txt for your approval login.'
    Write-Host '3. Put a few text PDFs in invoice_demo_v2\input and execute V2.'
    Write-Host '4. Open http://localhost:8787 to review the results.'
    Write-Host 'Outlook sending remains optional. Its V2 helper has NOT been started.'
    Start-Process 'http://localhost:8787'
} catch { Write-Host $_.Exception.Message -ForegroundColor Red; exit 1 }
