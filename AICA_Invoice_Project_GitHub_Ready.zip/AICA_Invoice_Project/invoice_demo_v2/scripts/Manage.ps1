param([ValidateSet('start','stop','status')][string]$Action = 'status')
. (Join-Path $PSScriptRoot 'Common.ps1')
try {
    Assert-Docker
    $null = Read-V2Environment
    switch ($Action) {
        'start' { Invoke-V2Compose -Arguments @('up','-d','approval'); Wait-V2Ready; Start-Process 'http://localhost:8787' }
        'stop' { Invoke-V2Compose -Arguments @('stop','approval'); Write-Host 'V2 stopped. Its database remains stored. V1 was not stopped.' }
        'status' { Invoke-V2Compose -Arguments @('ps','approval'); Write-Host 'Approval URL: http://localhost:8787'; Write-Host 'For application errors, inspect the invoice_v2/approval logs in Docker Desktop.' }
    }
} catch { Write-Host $_.Exception.Message -ForegroundColor Red; exit 1 }
