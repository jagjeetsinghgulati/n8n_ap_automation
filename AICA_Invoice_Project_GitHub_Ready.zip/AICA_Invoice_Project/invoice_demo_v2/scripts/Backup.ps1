. (Join-Path $PSScriptRoot 'Common.ps1')
try {
    $values = Read-V2Environment
    $login = @{ username=$values.INVOICE_USER; password=$values.INVOICE_PASSWORD } | ConvertTo-Json
    $session = New-Object Microsoft.PowerShell.Commands.WebRequestSession
    $reply = Invoke-RestMethod -Uri 'http://localhost:8787/api/login' -Method Post -ContentType 'application/json' -Body $login -WebSession $session
    $result = Invoke-RestMethod -Uri 'http://localhost:8787/api/backup' -Method Post -ContentType 'application/json' -Body '{}' -Headers @{'X-CSRF-Token'=$reply.csrf} -WebSession $session -TimeoutSec 300
    Write-Host "Backup created: $($result.filename)" -ForegroundColor Green
    Write-Host ('Folder: ' + (Join-Path $script:V2Root 'backups'))
    Write-Host 'Copy this ZIP to another disk for protection from disk failure. Keep .env and LOCAL_LOGIN_PRIVATE.txt separately and privately.'
} catch { Write-Host $_.Exception.Message -ForegroundColor Red; exit 1 }
