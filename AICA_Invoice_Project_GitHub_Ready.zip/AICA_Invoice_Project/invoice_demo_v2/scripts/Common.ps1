Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$script:V2Root = Split-Path -Parent $PSScriptRoot
$script:Utf8 = New-Object System.Text.UTF8Encoding($false)

function Assert-Docker {
    if (-not (Get-Command docker -ErrorAction SilentlyContinue)) { throw 'Docker was not found. Start Docker Desktop, then reopen this command window.' }
    & docker info --format '{{.ServerVersion}}' *> $null
    if ($LASTEXITCODE -ne 0) { throw 'Docker Desktop is not ready. Start it and wait for the engine to run.' }
    & docker compose version *> $null
    if ($LASTEXITCODE -ne 0) { throw 'Docker Compose v2 is required (included with Docker Desktop).' }
}
function Read-V2Environment {
    $path = Join-Path $script:V2Root '.env'
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw 'Run SETUP_V2.cmd first.' }
    $values = @{}
    foreach ($line in [IO.File]::ReadAllLines($path)) {
        if ($line -match '^([A-Z0-9_]+)=([A-Za-z0-9_.-]+)$') { $values[$Matches[1]] = $Matches[2] }
    }
    foreach ($key in @('N8N_NETWORK','INVOICE_API_TOKEN','INVOICE_USER','INVOICE_PASSWORD')) {
        if (-not $values.ContainsKey($key)) { throw "The .env setting $key is absent or invalid. Keep the original .env and investigate before resetting it." }
    }
    return $values
}
function Invoke-V2Compose {
    param([string[]]$Arguments)
    & docker compose --project-name invoice_v2 --project-directory $script:V2Root --env-file (Join-Path $script:V2Root '.env') -f (Join-Path $script:V2Root 'compose.v2.yaml') @Arguments
    if ($LASTEXITCODE -ne 0) { throw 'The V2 Docker operation failed. Review the message above. V1 was not changed.' }
}
function Wait-V2Ready {
    for ($attempt = 0; $attempt -lt 30; $attempt++) {
        try {
            $health = Invoke-RestMethod -Uri 'http://127.0.0.1:8787/api/health' -TimeoutSec 2
            if ($health.ok -and [string]$health.version -match '^2\.') { return }
        } catch { }
        Start-Sleep -Seconds 2
    }
    throw 'V2 did not become ready. Run STATUS_V2.cmd and check Docker Desktop > invoice_v2 > approval logs. Do not paste credentials into support messages.'
}
function New-V2Secret([int]$Bytes = 24) {
    $buffer = New-Object byte[] $Bytes
    $rng = [Security.Cryptography.RandomNumberGenerator]::Create()
    try { $rng.GetBytes($buffer) } finally { $rng.Dispose() }
    return ([BitConverter]::ToString($buffer)).Replace('-', '').ToLowerInvariant()
}
function Protect-V2File([string]$Path) {
    # Limit local secret files to this Windows identity, SYSTEM and Administrators.
    $sid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    & icacls $Path /inheritance:r /grant:r "*$($sid):(F)" '*S-1-5-18:(F)' '*S-1-5-32-544:(F)' *> $null
    if ($LASTEXITCODE -ne 0) { Write-Warning "Could not restrict permissions on $([IO.Path]::GetFileName($Path)). Keep this folder private to your Windows account." }
}
